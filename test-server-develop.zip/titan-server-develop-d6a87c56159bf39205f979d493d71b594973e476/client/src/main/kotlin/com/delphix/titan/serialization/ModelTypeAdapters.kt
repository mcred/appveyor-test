/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.serialization

import com.delphix.titan.models.EngineRemote
import com.delphix.titan.models.EngineRequest
import com.delphix.titan.models.NopRemote
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.OperationRequest
import com.delphix.titan.models.Remote
import com.delphix.titan.models.SshRemote
import com.delphix.titan.models.SshRequest
import com.google.gson.GsonBuilder

class ModelTypeAdapters {
    companion object {
        private val remote = RuntimeTypeAdapterFactory
                .of(Remote::class.java, "provider", true)
                .registerSubtype(NopRemote::class.java, "nop")
                .registerSubtype(EngineRemote::class.java, "engine")
                .registerSubtype(SshRemote::class.java, "ssh")

        private val request = RuntimeTypeAdapterFactory
                .of(OperationRequest::class.java, "provider", true)
                .registerSubtype(NopRequest::class.java, "nop")
                .registerSubtype(EngineRequest::class.java, "engine")
                .registerSubtype(SshRequest::class.java, "ssh")

        fun configure(builder: GsonBuilder) : GsonBuilder {
            return builder.registerTypeAdapterFactory(remote)
                    .registerTypeAdapterFactory(request)
        }
    }
}

