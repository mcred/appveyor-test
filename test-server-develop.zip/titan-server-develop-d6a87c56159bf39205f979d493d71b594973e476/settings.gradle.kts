rootProject.name = "titan"

val titanVersion = "0.2.1"

include("client")
include("server")
