/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.serialization

import com.delphix.titan.models.NopRemote
import com.delphix.titan.models.Remote
import com.delphix.titan.models.SshRemote
import io.kotlintest.matchers.types.shouldBeInstanceOf
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec

class UriParseTest : StringSpec() {

    fun parse(uri: String, map: Map<String, String>? = null): Remote {
        return RemoteUtil.parseUri(uri, "name", map ?: mapOf())
    }

    init {
        "parsing a nop URI succeeds" {
            val result = parse("nop")
            result.shouldBeInstanceOf<NopRemote>()
            result.name shouldBe "name"
        }

        "parsing URI with missing authority fails" {
            shouldThrow<IllegalArgumentException> {
                parse("nop://")
            }
        }

        "parsing nop URI authority fails" {
            shouldThrow<IllegalArgumentException> {
                parse("nop://foo")
            }
        }

        "parsing full SSH URI succeeds" {
            val result = parse("ssh://user:pass@host:8022/path")
            result.shouldBeInstanceOf<SshRemote>()
            val remote = result as SshRemote
            remote.name shouldBe "name"
            remote.username shouldBe "user"
            remote.password shouldBe "pass"
            remote.address shouldBe "host"
            remote.port shouldBe 8022
            remote.path shouldBe "/path"
            remote.keyFile shouldBe null
        }

        "parsing simple SSH URI succeeds" {
            val result = parse("ssh://user@host/path")
            result.shouldBeInstanceOf<SshRemote>()
            val remote = result as SshRemote
            remote.name shouldBe "name"
            remote.username shouldBe "user"
            remote.password shouldBe null
            remote.address shouldBe "host"
            remote.port shouldBe null
            remote.path shouldBe "/path"
            remote.keyFile shouldBe null
        }

        "specifying key file in properties succeeds" {
            val result = parse("ssh://user@host/path", mapOf("keyFile" to "~/.ssh/id_dsa"))
            result.shouldBeInstanceOf<SshRemote>()
            val remote = result as SshRemote
            remote.keyFile shouldBe "~/.ssh/id_dsa"
        }

        "specifying password and key file fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://user:password@host/path", mapOf("keyFile" to "~/.ssh/id_dsa"))
            }
        }

        "plain ssh provider fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh")
            }
        }

        "specifying query parameter fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://user@host/path?query")
            }
        }

        "specifying fragment fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://user@host/path#fragment")
            }
        }

        "missing username in ssh URI fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://host/path")
            }
        }

        "missing path in ssh URI fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://user@host")
            }
        }

        "missing host in ssh URI fails" {
            shouldThrow<IllegalArgumentException> {
                parse("ssh://user@/path")
            }
        }
    }
}
