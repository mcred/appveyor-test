/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.storage.zfs

import com.delphix.titan.exception.NoSuchObjectException
import com.delphix.titan.models.Commit
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.Operation
import com.delphix.titan.storage.OperationData
import com.delphix.titan.util.CommandException
import com.delphix.titan.util.CommandExecutor
import com.delphix.titan.util.GuidGenerator
import io.kotlintest.TestCase
import io.kotlintest.TestCaseOrder
import io.kotlintest.TestResult
import io.kotlintest.matchers.string.shouldContain
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec
import io.mockk.MockKAnnotations
import io.mockk.clearAllMocks
import io.mockk.confirmVerified
import io.mockk.every
import io.mockk.impl.annotations.InjectMockKs
import io.mockk.impl.annotations.MockK
import io.mockk.impl.annotations.OverrideMockKs
import io.mockk.verify
import io.mockk.verifySequence

class ZfsOperationTest : StringSpec() {

    @MockK
    lateinit var executor: CommandExecutor

    @MockK
    lateinit var generator: GuidGenerator

    @InjectMockKs
    @OverrideMockKs
    var provider = ZfsStorageProvider("test")

    override fun beforeTest(testCase: TestCase) {
        return MockKAnnotations.init(this)
    }

    override fun afterTest(testCase: TestCase, result: TestResult) {
        clearAllMocks()
    }

    override fun testCaseOrder() = TestCaseOrder.Random

    fun getOperation(): OperationData {
        val operation = Operation(id = "id", operationType = Operation.OperationType.PUSH,
                state = Operation.State.RUNNING, remote = "remote", commitId = "commit")
        return OperationData(operation = operation, request = NopRequest())
    }

    fun mockOperation() {
        val json = "{\"operation\":{\"id\":\"id\"," +
                "\"operationType\":\"PUSH\",\"state\":\"RUNNING\",\"remote\":\"remote\"," +
                "\"commitId\":\"commit\"},\"request\":{\"provider\":\"nop\"}}"
        every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                "test/foo") } returns "test/foo\t{}"
        every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:operation",
                "test/foo/id") } returns "test/foo/id\t$json"
    }

    init {
        "create operation fails if invalid repo name specified" {
            shouldThrow<IllegalArgumentException> {
                provider.createOperation("not/ok", getOperation())
            }
        }

        "create operation fails if invalid local commit used" {
            val operation = Operation(id = "id", operationType = Operation.OperationType.PUSH,
                    state = Operation.State.RUNNING, remote = "remote", commitId = "commit")
            val data = OperationData(operation = operation, request = NopRequest())
            shouldThrow<IllegalArgumentException> {
                provider.createOperation("repo", data, "not/ok")
            }
        }

        "create operation fails if invalid operation commit used" {
            val operation = Operation(id = "id", operationType = Operation.OperationType.PUSH,
                    state = Operation.State.RUNNING, remote = "remote", commitId = "not/ok")
            val data = OperationData(operation = operation, request = NopRequest())
            shouldThrow<IllegalArgumentException> {
                provider.createOperation("repo", data)
            }
        }

        "create operation fails if invalid operation id used" {
            val operation = Operation(id = "not/ok", operationType = Operation.OperationType.PUSH,
                    state = Operation.State.RUNNING, remote = "remote", commitId = "commit")
            shouldThrow<IllegalArgumentException> {
                provider.createOperation("repo",
                        OperationData(operation = operation, request = NopRequest()))
            }
        }

        "create operation fails for unknown repository" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.createOperation("foo", getOperation(), null)
            }
            exception.message shouldContain "repository"
        }

        "create operation succeeds" {
            every { executor.exec("zfs", "list", "-Ho", "name,defer_destroy", "-t", "snapshot",
                    "-d", "2", "test/foo")
            } returns "test/foo/guid@hash\toff"
            every { executor.exec("zfs", "list", "-rHo", "name", "test/foo/guid") } returns
                    arrayOf("test/foo/guid", "test/foo/guid/v0", "test/foo/guid/v1").joinToString("\n")
            every { executor.exec("zfs", "create", "test/foo/id") } returns ""
            every { executor.exec("zfs", "clone", "test/foo/guid/v0@hash",
                    "test/foo/id/v0") } returns ""
            every { executor.exec("zfs", "clone", "test/foo/guid/v1@hash",
                    "test/foo/id/v1") } returns ""
            val op = getOperation()
            val json = "{\"operation\":{\"id\":\"id\"," +
                    "\"operationType\":\"PUSH\",\"state\":\"RUNNING\",\"remote\":\"remote\"," +
                    "\"commitId\":\"commit\"},\"request\":{\"provider\":\"nop\",\"delay\":0}}"
            every { executor.exec("zfs", "set", "com.delphix.titan:operation=$json", "test/foo/id") } returns ""
            provider.createOperation("foo", op, "hash")

            verifySequence {
                executor.exec("zfs", "list", "-Ho", "name,defer_destroy", "-t", "snapshot",
                        "-d", "2", "test/foo")
                executor.exec("zfs", "list", "-rHo", "name", "test/foo/guid")
                executor.exec("zfs", "create", "test/foo/id")
                executor.exec("zfs", "clone", "test/foo/guid/v0@hash", "test/foo/id/v0")
                executor.exec("zfs", "clone", "test/foo/guid/v1@hash", "test/foo/id/v1")
                executor.exec("zfs", "set", "com.delphix.titan:operation=$json", "test/foo/id")
            }
            confirmVerified()
        }

        "list operations returns an empty list" {
            every { executor.exec(*anyVararg()) } returns ""
            val result = provider.listOperations("foo")
            result.size shouldBe 0
        }

        "list operations throws exception for no such repository" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            shouldThrow<NoSuchObjectException> {
                provider.listOperations("foo")
            }
        }

        "list operations returns correct result" {
            val op1 = OperationData(operation = Operation(id = "id1",
                    operationType = Operation.OperationType.PUSH,
                    state = Operation.State.RUNNING, remote = "remote", commitId = "commit1"),
                    request = NopRequest())
            val json1 = provider.gson.toJson(op1)
            val op2 = OperationData(operation = Operation(id = "id2",
                    operationType = Operation.OperationType.PULL,
                    state = Operation.State.RUNNING, remote = "remote", commitId = "commit2"),
                    request = NopRequest())
            val json2 = provider.gson.toJson(op2)
            every { executor.exec(*anyVararg()) } returns arrayOf(
                    "test/foo\t-",
                    "test/foo/nottop\t-",
                    "test/foo/id1\t$json1",
                    "test/foo/id2\t$json2"
                    ).joinToString("\n")

            val result = provider.listOperations("foo")
            result.size shouldBe 2
            result[0].operation.id shouldBe op1.operation.id
            result[0].operation.commitId shouldBe op1.operation.commitId
            result[1].operation.id shouldBe op2.operation.id
            result[1].operation.commitId shouldBe op2.operation.commitId
        }

        "get operation for non existent repo fails" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.getOperation("foo", "op")
            }
            exception.message shouldContain "repository"
        }

        "get operation for non existent operation fails" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:operation",
                    "test/foo/op") } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.getOperation("foo", "op")
            }
            exception.message shouldContain "operation"
        }

        "get operation for a normal guid fails" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:operation",
                    "test/foo/op") } returns "test/foo/op\t-"
            val exception = shouldThrow<NoSuchObjectException> {
                provider.getOperation("foo", "op")
            }
            exception.message shouldContain "operation"
        }

        "get operation succeeds" {
            mockOperation()
            val op = provider.getOperation("foo", "id")
            op.operation.id shouldBe "id"
            op.operation.commitId shouldBe "commit"
        }

        "commit operation fails for unknown repo" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                val commit = Commit(id = "commit", properties = mapOf("a" to "b"))
                provider.commitOperation("foo", "id", commit)
            }
            exception.message shouldContain "repository"
        }

        "commit operation succeeds" {
            mockOperation()
            every { executor.exec("zfs", "snapshot", "-r", "-o",
                    "com.delphix.titan:metadata={\"a\":\"b\"}", "test/foo/id@commit") } returns ""
            every { executor.exec("zfs", "inherit", "com.delphix.titan:operation",
                    "test/foo/id") } returns ""

            val commit = Commit(id = "commit", properties = mapOf("a" to "b"))
            provider.commitOperation("foo", "id", commit)

            verify {
                executor.exec("zfs", "snapshot", "-r", "-o",
                        "com.delphix.titan:metadata={\"a\":\"b\"}", "test/foo/id@commit")
                executor.exec("zfs", "inherit", "com.delphix.titan:operation",
                        "test/foo/id")
            }
        }

        "discard operation fails for unknown repo" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.discardOperation("foo", "id")
            }
            exception.message shouldContain "repository"
        }

        "discard operation succeeds" {
            mockOperation()
            every { executor.exec("zfs", "destroy", "-r", "test/foo/id") } returns ""

            provider.discardOperation("foo", "id")

            verify {
                executor.exec("zfs", "destroy", "-r", "test/foo/id")
            }
        }

        "update operation state fails for unknown repo" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.updateOperationState("foo", "id", Operation.State.COMPLETE)
            }
            exception.message shouldContain "repository"
        }

        "update operation state succeeds" {
            mockOperation()
            val newJson = "{\"operation\":{\"id\":\"id\"," +
                    "\"operationType\":\"PUSH\",\"state\":\"COMPLETE\",\"remote\":\"remote\"," +
                    "\"commitId\":\"commit\"},\"request\":{\"provider\":\"nop\",\"delay\":0}}"
            every { executor.exec("zfs", "set", "com.delphix.titan:operation=$newJson",
                    "test/foo/id") } returns ""

            provider.updateOperationState("foo", "id", Operation.State.COMPLETE)

            verify {
                executor.exec("zfs", "set", "com.delphix.titan:operation=$newJson",
                        "test/foo/id")
            }
        }

        "mount operation volumes fail for unknown repo" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.mountOperationVolumes("foo", "id")
            }
            exception.message shouldContain "repository"
        }

        "mount operation volumes succeeds" {
            mockOperation()
            every { executor.exec("zfs", "list", "-Hpo", "com.delphix.titan:active",
                    "test/foo") } returns "guid"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "-r", "test/foo/guid") } returns arrayOf(
                    "test/foo/guid/one\t{\"a\":\"b\"}",
                    "test/foo/guid/two\t{\"c\":\"d\"}"
            ).joinToString("\n")
            every { executor.exec("mount", "-t", "zfs",
                    "test/foo/id/one", "/var/lib/test/mnt/id/one") } returns ""
            every { executor.exec("mount", "-t", "zfs",
                    "test/foo/id/two", "/var/lib/test/mnt/id/two") } returns ""
            val result = provider.mountOperationVolumes("foo", "id")
            result shouldBe "/var/lib/test/mnt/id"

            verify {
                executor.exec("mount", "-t", "zfs",
                        "test/foo/id/one", "/var/lib/test/mnt/id/one")
                executor.exec("mount", "-t", "zfs",
                        "test/foo/id/two", "/var/lib/test/mnt/id/two")
            }
        }

        "unmount operation volumes fail for unknown repo" {
            every { executor.exec(*anyVararg()) } throws CommandException("", 1, "does not exist")
            val exception = shouldThrow<NoSuchObjectException> {
                provider.unmountOperationVolumes("foo", "id")
            }
            exception.message shouldContain "repository"
        }

        "unmount operation volumes succeeds" {
            mockOperation()
            every { executor.exec("zfs", "list", "-Hpo", "com.delphix.titan:active",
                    "test/foo") } returns "guid"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "-r", "test/foo/guid") } returns arrayOf(
                    "test/foo/guid/one\t{\"a\":\"b\"}",
                    "test/foo/guid/two\t{\"c\":\"d\"}"
            ).joinToString("\n")
            every { executor.exec("umount", "/var/lib/test/mnt/id/one") } returns ""
            every { executor.exec("umount", "/var/lib/test/mnt/id/two") } returns ""
            provider.unmountOperationVolumes("foo", "id")

            verify {
                executor.exec("umount", "/var/lib/test/mnt/id/one")
                executor.exec("umount", "/var/lib/test/mnt/id/two")
            }
        }
    }
}
