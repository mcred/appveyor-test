/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.remote.ssh

import com.delphix.titan.exception.NoSuchObjectException
import com.delphix.titan.exception.ObjectExistsException
import com.delphix.titan.models.Operation
import com.delphix.titan.models.SshRemote
import com.delphix.titan.util.CommandException
import com.delphix.titan.util.CommandExecutor
import io.kotlintest.TestCase
import io.kotlintest.TestCaseOrder
import io.kotlintest.TestResult
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec
import io.mockk.MockKAnnotations
import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.impl.annotations.InjectMockKs
import io.mockk.impl.annotations.MockK
import io.mockk.impl.annotations.OverrideMockKs
import io.mockk.slot
import java.io.File

class SshRemoteProviderTest : StringSpec() {

    @MockK
    lateinit var executor: CommandExecutor

    @InjectMockKs
    @OverrideMockKs
    var provider = SshRemoteProvider()

    override fun beforeTest(testCase: TestCase) {
        return MockKAnnotations.init(this)
    }

    override fun afterTest(testCase: TestCase, result: TestResult) {
        clearAllMocks()
    }

    override fun testCaseOrder() = TestCaseOrder.Random

    fun getRemote(): SshRemote {
        return SshRemote(
                name = "remote",
                address = "localhost",
                username = "root",
                password = "root",
                path = "/var/tmp"
        )
    }

    init {
        "list commits returns an empty list" {
            every { executor.exec(*anyVararg()) } returns ""
            val result = provider.listCommits(getRemote())
            result.size shouldBe 0
        }

        "list commits returns correct metadata" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "ls", "-1", "/var/tmp") } returns "a\nb\n"
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } returns "{\"id\":\"a\",\"properties\":{}}"
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/b/metadata.json") } returns "{\"id\":\"b\",\"properties\":{}}"
            val result = provider.listCommits(getRemote())
            result.size shouldBe 2
            result[0].id shouldBe "a"
            result[1].id shouldBe "b"
        }

        "list commits ignores missing file" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "ls", "-1", "/var/tmp") } returns "a\n"
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } throws CommandException("", 1,
                    "no such file or directory")

            val result = provider.listCommits(getRemote())
            result.size shouldBe 0
        }

        "get commit returns failure if file doesn't exist" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } throws CommandException("", 1,
                    "no such file or directory")
            shouldThrow<NoSuchObjectException> {
                provider.getCommit(getRemote(), "a")
            }
        }

        "get commit returns correct metadata" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } returns "{\"id\":\"a\",\"properties\":{\"b\":\"c\"}}"
            val commit = provider.getCommit(getRemote(), "a")
            commit.id shouldBe "a"
            commit.properties!!["b"] shouldBe "c"
        }

        "temporary password file is correctly removed" {
            val slot = slot<String>()
            every { executor.exec("sshpass", "-f", capture(slot), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } returns "{\"id\":\"a\",\"properties\":{\"b\":\"c\"}}"
            provider.getCommit(getRemote(), "a")
            val file = File(slot.captured)
            file.exists() shouldBe false
        }

        "validate pull operation succeeds if remote commit exists" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } returns "{\"id\":\"a\",\"properties\":{}}"
            provider.validateOperation(getRemote(), "a", Operation.OperationType.PULL)
        }

        "validate pull operation fails if remote commit does not exist" {
            every {
                executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                        "cat", "/var/tmp/a/metadata.json")
            } throws CommandException("", 1, "no such file")
            shouldThrow<NoSuchObjectException> {
                provider.validateOperation(getRemote(), "a", Operation.OperationType.PULL)
            }
        }

        "validate push operation succeeds if remote commit does not exists" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } throws CommandException("", 1, "no such file")
            provider.validateOperation(getRemote(), "a", Operation.OperationType.PUSH)
        }

        "validate pull operation fails if remote commit exists" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "cat", "/var/tmp/a/metadata.json") } returns "{\"id\":\"a\",\"properties\":{}}"
            shouldThrow<ObjectExistsException> {
                provider.validateOperation(getRemote(), "a", Operation.OperationType.PUSH)
            }
        }

        "add remote creates necessary directory" {
            every { executor.exec("sshpass", "-f", any(), "ssh", "-o", "StrictHostKeyChecking=no",
                    "mkdir", "-p", "/var/tmp") } returns ""
            provider.addRemote(getRemote())
        }

        "remote remote does nothing" {
            provider.removeRemote(getRemote())
        }

        "update remote does nothing" {
            provider.updateRemote(getRemote(), getRemote())
        }
    }
}
