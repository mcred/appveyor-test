/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.serialization

import com.delphix.titan.models.EngineRemote
import com.delphix.titan.models.EngineRequest
import com.delphix.titan.models.NopRemote
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.OperationRequest
import com.delphix.titan.models.Remote
import com.delphix.titan.models.SshRemote
import com.delphix.titan.models.SshRequest
import com.google.gson.GsonBuilder
import com.google.gson.JsonParseException
import com.google.gson.reflect.TypeToken
import io.kotlintest.matchers.types.shouldBeInstanceOf
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec

class SerializationTest : StringSpec() {

    val gson = ModelTypeAdapters.configure(GsonBuilder()).create()

    init {
        "serializing a nop remote succeeds" {
            val result = gson.toJson(NopRemote(name = "foo"))
            result.shouldBe("{\"provider\":\"nop\",\"name\":\"foo\"}")
        }

        "deserializing a nop remote succeeds" {
            val result = gson.fromJson("{\"provider\":\"nop\",\"name\":\"foo\"}", Remote::class.java)
            result.shouldBeInstanceOf<NopRemote>()
            result.provider shouldBe "nop"
            result.name shouldBe "foo"
        }

        "deserializing an unknown provider type fails" {
            shouldThrow<JsonParseException> {
                gson.fromJson("{\"provider\":\"blah\",\"name\":\"foo\"}",
                        Remote::class.java)
            }
        }

        "serializing an engine remote succeeds" {
            val result = gson.toJson(EngineRemote(name = "foo",
                    address = "a", username = "u", password = "p"))
            result.shouldBe("{\"provider\":\"engine\",\"name\":\"foo\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"password\":\"p\"}")
        }

        "deserializing an engine remote succeeds" {
            val result = gson.fromJson("{\"provider\":\"engine\",\"name\":\"foo\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"password\":\"p\"}", EngineRemote::class.java)
            result.shouldBeInstanceOf<EngineRemote>()
            result.provider shouldBe "engine"
            result.name shouldBe "foo"
            result.username shouldBe "u"
            result.password shouldBe "p"
        }

        "serializing a ssh remote succeeds" {
            val result = gson.toJson(SshRemote(name = "foo",
                    address = "a", username = "u", password = "p", path = "/p"))
            result.shouldBe("{\"provider\":\"ssh\",\"name\":\"foo\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"password\":\"p\",\"path\":\"/p\"}")
        }

        "serializing a ssh remote with key file succeeds" {
            val result = gson.toJson(SshRemote(name = "foo",
                    address = "a", username = "u", keyFile = "p", path = "/p"))
            result.shouldBe("{\"provider\":\"ssh\",\"name\":\"foo\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"keyFile\":\"p\",\"path\":\"/p\"}")
        }

        "deserializing a ssh remote succeeds" {
            val result = gson.fromJson("{\"provider\":\"ssh\",\"name\":\"foo\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"password\":\"p\",\"path\":\"/p\"}", Remote::class.java)
            result.shouldBeInstanceOf<SshRemote>()
            val remote = result as SshRemote
            remote.provider shouldBe "ssh"
            remote.name shouldBe "foo"
            remote.username shouldBe "u"
            remote.password shouldBe "p"
            remote.path shouldBe "/p"
        }

        "deserializing a list of remotes succeeds" {
            val listType = object : TypeToken<List<Remote>>() { }.type
            val result = gson.fromJson<List<Remote>>("[{\"provider\":\"nop\",\"name\":\"foo\"}," +
                    "{\"provider\":\"engine\",\"name\":\"bar\",\"address\":\"a\"," +
                    "\"username\":\"u\",\"password\":\"p\"}]", listType)
            result.size shouldBe 2
            result[0].shouldBeInstanceOf<NopRemote>()
            result[0].provider shouldBe "nop"
            result[0].name shouldBe "foo"
            result[1].shouldBeInstanceOf<EngineRemote>()
            result[1].provider shouldBe "engine"
            result[1].name shouldBe "bar"
            (result[1] as EngineRemote).username shouldBe "u"
            (result[1] as EngineRemote).address shouldBe "a"
            (result[1] as EngineRemote).password shouldBe "p"
        }

        "serializing a nop request succeeds" {
            val result = gson.toJson(NopRequest())
            result.shouldBe("{\"provider\":\"nop\",\"delay\":0}")
        }

        "deserializing a nop request succeeds" {
            val result = gson.fromJson("{\"provider\":\"nop\"}", OperationRequest::class.java)
            result.shouldBeInstanceOf<NopRequest>()
            result.provider shouldBe "nop"
        }

        "deserializing an unknown request provider fails" {
            shouldThrow<JsonParseException> {
                gson.fromJson("{\"provider\":\"blah\"}",
                        OperationRequest::class.java)
            }
        }

        "serializing an engine request succeeds" {
            val result = gson.toJson(EngineRequest(password = "p"))
            result.shouldBe("{\"provider\":\"engine\",\"password\":\"p\"}")
        }

        "deserializing an engine request succeeds" {
            val result = gson.fromJson("{\"provider\":\"engine\",\"password\":\"p\"}",
                    OperationRequest::class.java)
            result.shouldBeInstanceOf<EngineRequest>()
            val request = result as EngineRequest
            request.provider shouldBe "engine"
            request.password shouldBe "p"
        }

        "serializing a ssh request succeeds" {
            val result = gson.toJson(SshRequest(password = "p"))
            result.shouldBe("{\"provider\":\"ssh\",\"password\":\"p\"}")
        }

        "deserializing a ssh request succeeds" {
            val result = gson.fromJson("{\"provider\":\"ssh\",\"password\":\"p\"}",
                    OperationRequest::class.java)
            result.shouldBeInstanceOf<SshRequest>()
            val request = result as SshRequest
            request.provider shouldBe "ssh"
            request.password shouldBe "p"
        }
    }
}
