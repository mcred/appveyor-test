/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.exception

class ObjectExistsException(message: String) : Exception(message)
