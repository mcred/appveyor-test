import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

buildscript {
    repositories {
        mavenCentral()
        maven("https://plugins.gradle.org/m2/")
    }

    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.3.31")
    }
}

val titanVersion by extra("0.2.0")

tasks.register("check")

allprojects {
    tasks.withType<KotlinCompile>().configureEach {
        kotlinOptions {
            jvmTarget = "1.8"
            allWarningsAsErrors = true
            freeCompilerArgs += "-Xuse-experimental=kotlin.Experimental"
        }
    }

    tasks.register("style") {
        group = "Verification"
        description = "Run all style checks"
    }

}
