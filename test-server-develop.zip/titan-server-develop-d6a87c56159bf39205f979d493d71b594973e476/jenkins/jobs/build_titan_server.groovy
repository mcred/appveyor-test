/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */
import static lib.JobDslSupport.isDeveloperJenkinsInstance

pipelineJob('build-titan-server') {

  description("Build and Publish Delphix Titan Server Docker Container")

  parameters {
    booleanParam 'DRY_RUN', false,
        """<p>[OPTIONAL] Builds the package, but doesn't publish.</p>"""
  }

  environmentVariables {
    env 'GIT_URL', GIT_URL
    env 'GIT_BRANCH', GIT_BRANCH
  }

  concurrentBuild false
  logRotator 30

  if (!isDeveloperJenkinsInstance()) {
    triggers { scm 'H/5 * * * *' }
  }

  definition {
    cps {
      script(readFileFromWorkspace('jenkins/jobs/pipelines/build_titan_server.groovy'))
      sandbox()
    }
  }
}
