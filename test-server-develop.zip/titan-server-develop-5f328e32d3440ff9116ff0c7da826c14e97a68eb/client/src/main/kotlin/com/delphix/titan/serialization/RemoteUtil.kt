/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.serialization

import com.delphix.titan.models.EngineRemote
import com.delphix.titan.models.NopRemote
import com.delphix.titan.models.Remote
import com.delphix.titan.models.SshRemote
import java.net.URI
import java.net.URISyntaxException


class RemoteUtil {

    companion object {
        fun parseUri(uriString: String, name: String, properties: Map<String, String>) : Remote {
            try {
                val uri = URI(uriString)

                val provider = uri.scheme ?: uriString

                if (uri.query != null || uri.fragment != null) {
                    throw IllegalArgumentException("Malformed remote identifier")
                }

                return when(provider) {
                    "nop" -> parseNop(uri, name, properties)
                    "ssh" -> parseSsh(uri, name, properties)
                    "engine" -> parseEngine(uri, name, properties)
                    else -> throw IllegalArgumentException("Unknown remote provider or malformed remote identifier")
                }
            } catch (e: URISyntaxException) {
                throw IllegalArgumentException("Invalid URI syntax", e)
            }
        }

        /**
         * Parse a nop remote. This is a really simple remote, that must always be "nop" with no
         * additional URI trimmings.
         */
        private fun parseNop(uri: URI, name: String, properties: Map<String, String>) : NopRemote {
            if (uri.scheme != null && (uri.authority != null || uri.path != null)) {
                throw IllegalArgumentException("Malformed remote identifier")
            }
            for (p in properties) {
                throw IllegalArgumentException("Invalid property '${p.key}'")
            }
            return NopRemote(name=name)
        }

        /**
         * Parse a SSH remote. The URI syntax for this is:
         *
         *      ssh://user[:password]@host[:port]/path
         *
         * If the password is not specified, then it is up to the client to prompt the user for it
         * and pass the value each time a request is made. The following properties are supported:
         *
         *      keyFile     Path, on the user's machine, of an SSH key file to use. If specified,
         *                  then the client must pass the contents of this file with each request.
         *                  This is mutually exclusive with a password.
         */
        @Suppress("UNUSED_PARAMETER")
        private fun parseSsh(uri: URI, name: String, properties: Map<String, String>) : SshRemote {
            if (uri.scheme == null) {
                throw IllegalArgumentException("Malformed remote identifier")
            }
            if (uri.userInfo == null) {
                throw IllegalArgumentException("Missing username in SSH remote identifier")
            }
            var username = uri.userInfo
            var password : String? = null
            if (uri.userInfo.contains(":")) {
                username = uri.userInfo.substringBefore(":")
                password = uri.userInfo.substringAfter(":")
            }

            if (uri.host == null || uri.host == "") {
                throw IllegalArgumentException("Missing host in SSH remote identifier")
            }
            val port : Int? = when (uri.port) {
                -1 -> null
                else -> uri.port
            }
            if (uri.path == null || uri.path == "") {
                throw IllegalArgumentException("Missing path in SSH remote identifier")
            }

            val keyFile = properties["keyFile"]

            if (keyFile != null && password != null) {
                throw IllegalArgumentException("Both password and key file cannot be specified for SSH remote")
            }

            // TODO Reject invalid properties

            return SshRemote(name=name, username=username, password=password, address=uri.host,
                    port=port, path=uri.path, keyFile=keyFile)
        }

        @Suppress("UNUSED_PARAMETER")
        private fun parseEngine(uri: URI, name: String?, properties: Map<String, String>?) : EngineRemote {
            throw NotImplementedError()
        }
    }
}
