var buildDockerServer = tasks.register<Exec>("buildDockerServer") {
    group = LifecycleBasePlugin.BUILD_GROUP
    description = "Build docker server image"
    commandLine("docker", "build", "-t", "delphix/titan:latest", "-f", "${project.projectDir}/docker/server.Dockerfile", "${project.projectDir}")
    mustRunAfter(tasks.named("shadowJar"))
}

var tagDockerServer = tasks.register<Exec>("tagDockerServer") {
    group = LifecycleBasePlugin.BUILD_GROUP
    description = "Tag docker server image with current version"
    commandLine("docker", "tag", "delphix/titan:latest", "delphix/titan:${project.version}")
    mustRunAfter(tasks.named("buildDockerServer"))
}

var tagLocalDockerServer = tasks.register<Exec>("tagLocalDockerServer") {
    group = LifecycleBasePlugin.BUILD_GROUP
    description = "Tag docker server image with current version"
    commandLine("docker", "tag", "delphix/titan:latest", "titan:latest")
    mustRunAfter(tasks.named("buildDockerServer"))
}


tasks.named("assemble").configure {
    dependsOn(buildDockerServer)
    dependsOn(tagDockerServer)
    dependsOn(tagLocalDockerServer)
}

var publishDockerVersion = tasks.register<Exec>("publishDockerVersion") {
    group = "Publishing"
    description = "Publish versioned docker server image to docker hub"
    commandLine("docker", "push", "delphix/titan:${project.version}")
    mustRunAfter(tasks.named("tagDockerServer"))
}

var publishDockerLatest = tasks.register<Exec>("publishDockerLatest") {
    group = "Publishing"
    description = "Publish latest docker server image to docker hub"
    commandLine("docker", "push", "delphix/titan:latest")
    mustRunAfter(tasks.named("publishDockerVersion"))
}

tasks.named("publish").configure {
    dependsOn(publishDockerVersion)
    dependsOn(publishDockerLatest)
}

