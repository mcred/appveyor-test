/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.remote.ssh

import com.delphix.titan.ProviderModule
import com.delphix.titan.exception.NoSuchObjectException
import com.delphix.titan.exception.ObjectExistsException
import com.delphix.titan.models.Commit
import com.delphix.titan.models.Operation
import com.delphix.titan.models.Remote
import com.delphix.titan.models.SshRemote
import com.delphix.titan.operation.OperationExecutor
import com.delphix.titan.remote.RemoteProvider
import com.delphix.titan.serialization.ModelTypeAdapters
import com.delphix.titan.util.CommandException
import com.delphix.titan.util.CommandExecutor
import com.google.gson.GsonBuilder

class SshRemoteProvider() : RemoteProvider {

    internal val executor = CommandExecutor()
    internal val gson = ModelTypeAdapters.configure(GsonBuilder()).create()

    private fun runSsh(remote: Remote, vararg command: String): String {
        val sshRemote = remote as SshRemote

        var args = mutableListOf<String>()
        var file = createTempFile()
        try {
            if (sshRemote.password != null) {
                args.addAll(arrayOf("sshpass", "-f", file.path, "ssh"))
            } else {
                args.addAll(arrayOf("ssh"))
                throw NotImplementedError()
            }
            file.setReadOnly()

            if (remote.port != null) {
                args.addAll(arrayOf("-p", remote.port.toString()))
            }

            args.addAll(arrayOf("-o", "StrictHostKeyChecking=no"))
            args.addAll(command)

            return executor.exec(*args.toTypedArray())
        } finally {
            file.delete()
        }
    }

    override fun addRemote(remote: Remote) {
        val sshRemote = remote as SshRemote

        runSsh(remote, "mkdir", "-p", sshRemote.path)
    }

    override fun removeRemote(remote: Remote) {
        // Nothing to do
    }

    override fun updateRemote(old: Remote, new: Remote) {
        // Nothing to do
    }

    override fun listCommits(remote: Remote): List<Commit> {
        val sshRemote = remote as SshRemote

        val output = runSsh(remote, "ls", "-1", sshRemote.path)
        val commits = mutableListOf<Commit>()
        for (line in output.lines()) {
            val commitId = line.trim()
            if (commitId != "") {
                try {
                    commits.add(getCommit(remote, commitId))
                } catch (e: NoSuchObjectException) {
                    // Ignore broken links
                }
            }
        }

        return commits
    }

    override fun getCommit(remote: Remote, commitId: String): Commit {
        val sshRemote = remote as SshRemote

        try {
            val json = runSsh(remote, "cat", "${sshRemote.path}/$commitId/metadata.json")
            return gson.fromJson(json, Commit::class.java)
        } catch (e: CommandException) {
            if (e.output.contains("no such file")) {
                throw NoSuchObjectException("no such commit $commitId in remote '${remote.name}'")
            }
            throw e
        }
    }

    override fun validateOperation(remote: Remote, commitId: String, opType: Operation.OperationType) {
        if (opType == Operation.OperationType.PULL) {
            getCommit(remote, commitId)
        } else {
            try {
                getCommit(remote, commitId)
                throw ObjectExistsException("commit $commitId exists in remote '${remote.name}'")
            } catch (e: NoSuchObjectException) {
                // Ignore
            }
        }
    }

    override fun runOperation(providers: ProviderModule, operation: OperationExecutor) {
        throw NotImplementedError() // TODO
    }
}
