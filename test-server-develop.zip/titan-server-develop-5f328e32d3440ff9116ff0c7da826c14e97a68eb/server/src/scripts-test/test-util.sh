#!/usr/bin/env bats

util_script=/test/src/scripts/util.sh

@test "timestamp returns date output" {
  source $util_script
  function date() { echo "date"; }
  export -f date
  run timestamp
  [ $status -eq 0 ]
  [ "$output" = "date" ]
}

@test "log begin prints marker" {
  source $util_script
  function timestamp { echo "ts"; }
  export -f timestamp
  run log_begin
  [ $status -eq 0 ]
  [ "$output" = "ts TITAN BEGIN" ]
}

@test "log start prints marker" {
  source $util_script
  function timestamp { echo "ts"; }
  export -f timestamp
  run log_start "this is my message"
  [ $status -eq 0 ]
  [ "$output" = "ts TITAN START this is my message" ]
}

@test "log end prints marker" {
  source $util_script
  function timestamp { echo "ts"; }
  export -f timestamp
  run log_end
  [ $status -eq 0 ]
  [ "$output" = "ts TITAN END" ]
}

@test "log error exits program" {
  source $util_script
  source $util_script
  function timestamp { echo "ts"; }
  export -f timestamp
  run log_error "this is my message"
  [ $status -eq 1 ]
  [ "$output" = "ts TITAN ERROR this is my message" ]
}
