/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan

import com.delphix.titan.models.Error
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.Operation
import com.delphix.titan.serialization.ModelTypeAdapters
import com.delphix.titan.storage.OperationData
import com.delphix.titan.storage.zfs.ZfsStorageProvider
import com.delphix.titan.util.CommandExecutor
import com.delphix.titan.util.GuidGenerator
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import io.kotlintest.Spec
import io.kotlintest.TestCase
import io.kotlintest.TestCaseOrder
import io.kotlintest.TestResult
import io.kotlintest.shouldBe
import io.kotlintest.specs.StringSpec
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.TestApplicationEngine
import io.ktor.server.testing.contentType
import io.ktor.server.testing.createTestEnvironment
import io.ktor.server.testing.handleRequest
import io.ktor.server.testing.setBody
import io.ktor.util.KtorExperimentalAPI
import io.mockk.MockKAnnotations
import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.impl.annotations.InjectMockKs
import io.mockk.impl.annotations.MockK
import io.mockk.impl.annotations.OverrideMockKs
import kotlinx.coroutines.time.delay
import java.time.Duration
import java.util.concurrent.TimeUnit

@UseExperimental(KtorExperimentalAPI::class)
class OperationsApiTest : StringSpec() {

    @MockK
    lateinit var executor: CommandExecutor

    @MockK
    lateinit var generator: GuidGenerator

    @InjectMockKs
    @OverrideMockKs
    var zfsStorageProvider = ZfsStorageProvider("test")

    @InjectMockKs
    @OverrideMockKs
    var providers = ProviderModule("test")

    var engine = TestApplicationEngine(createTestEnvironment())

    val gson = ModelTypeAdapters.configure(GsonBuilder()).create()

    override fun beforeSpec(spec: Spec) {
        with(engine) {
            start()
            application.mainProvider(providers)
        }
    }

    override fun afterSpec(spec: Spec) {
        engine.stop(0L, 0L, TimeUnit.MILLISECONDS)
    }

    override fun beforeTest(testCase: TestCase) {
        providers.operation.clearState()
        return MockKAnnotations.init(this)
    }

    override fun afterTest(testCase: TestCase, result: TestResult) {
        clearAllMocks()
    }

    override fun testCaseOrder() = TestCaseOrder.Random

    fun loadOperations(repo: String, vararg operations: OperationData) {
        every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                "test/$repo") } returns "test/$repo\t{}"
        every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                "-d", "1", "test") } returns "test/$repo\t{}"
        val lines = operations.map { o -> "test/$repo/${o.operation.id}\t" + gson.toJson(o) }
        every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:operation",
                "-d", "1", "test/foo") } returns lines.joinToString("\n")
        every { executor.exec("zfs", "list", "-Ho", "com.delphix.titan:remotes",
                "test/$repo") } returns "[{\"name\":\"remote\",\"provider\":\"nop\"}]"
        providers.operation.loadState()
    }

    fun loadTestOperations() {
        val op1 = OperationData(operation = Operation(id = "id1",
                operationType = Operation.OperationType.PUSH,
                state = Operation.State.COMPLETE, remote = "remote", commitId = "commit1"),
                request = NopRequest())
        val op2 = OperationData(operation = Operation(id = "id2",
                operationType = Operation.OperationType.PULL,
                state = Operation.State.COMPLETE, remote = "remote", commitId = "commit2"),
                request = NopRequest())
        loadOperations("foo", op1, op2)
    }

    init {
        "list empty operations succeeds" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations")) {
                response.status() shouldBe HttpStatusCode.OK
                response.contentType().toString() shouldBe "application/json; charset=UTF-8"
                response.content shouldBe "[]"
            }
        }

        "list operations succeeds" {
            loadTestOperations()
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations")) {
                response.status() shouldBe HttpStatusCode.OK
                response.contentType().toString() shouldBe "application/json; charset=UTF-8"
                response.content shouldBe "[{\"id\":\"id1\",\"operationType\":\"PUSH\"," +
                        "\"state\":\"COMPLETE\",\"remote\":\"remote\",\"commitId\":\"commit1\"}," +
                        "{\"id\":\"id2\",\"operationType\":\"PULL\",\"state\":\"COMPLETE\"," +
                        "\"remote\":\"remote\",\"commitId\":\"commit2\"}]"
            }
        }

        "get operation fails for non-existent operation" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "-d", "1", "test") } returns "test/foo\t{}"
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id")) {
                response.status() shouldBe HttpStatusCode.NotFound
                val error = Gson().fromJson(response.content, Error::class.java)
                error.code shouldBe "NoSuchObjectException"
                error.message shouldBe "no such operation 'id' in repository 'foo'"
            }
        }

        "get operation succeeds" {
            loadTestOperations()
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id1")) {
                response.status() shouldBe HttpStatusCode.OK
                response.contentType().toString() shouldBe "application/json; charset=UTF-8"
                response.content shouldBe "{\"id\":\"id1\",\"operationType\":\"PUSH\"," +
                    "\"state\":\"COMPLETE\",\"remote\":\"remote\",\"commitId\":\"commit1\"}"
            }
        }

        "abort in-progress operation results in aborted state" {
            loadOperations("foo", OperationData(Operation(id = "id",
                    operationType = Operation.OperationType.PUSH, commitId = "commit",
                    state = Operation.State.RUNNING, remote = "remote"),
                    request = NopRequest(delay = 10)))
            with(engine.handleRequest(HttpMethod.Delete, "/v1/repositories/foo/operations/id")) {
                response.status() shouldBe HttpStatusCode.NoContent
            }

            delay(Duration.ofMillis(500))

            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id")) {
                response.status() shouldBe HttpStatusCode.OK
                val op = gson.fromJson(response.content, Operation::class.java)
                op.state shouldBe Operation.State.ABORTED
            }
        }

        "abort completed operation doesn't alter operation" {
            loadTestOperations()
            with(engine.handleRequest(HttpMethod.Delete, "/v1/repositories/foo/operations/id1")) {
                response.status() shouldBe HttpStatusCode.NoContent
            }

            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id1")) {
                response.status() shouldBe HttpStatusCode.OK
                response.content shouldBe "{\"id\":\"id1\",\"operationType\":\"PUSH\"," +
                        "\"state\":\"COMPLETE\",\"remote\":\"remote\",\"commitId\":\"commit1\"}"
            }
        }

        "get progress returns correct state" {
            loadOperations("foo", OperationData(Operation(id = "id",
                    operationType = Operation.OperationType.PUSH, commitId = "commit",
                    state = Operation.State.RUNNING, remote = "remote"),
                    request = NopRequest(delay = 10)))
            delay(Duration.ofMillis(500))
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id/progress")) {
                response.status() shouldBe HttpStatusCode.OK
                response.content shouldBe "[{\"type\":\"END\",\"message\":\"Retrying operation after restart\"},{\"type\":\"START\",\"message\":\"Running operation\"}]"
            }
        }

        "get progress of completed operation removes operation" {
            loadTestOperations()
            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id1/progress")) {
                response.status() shouldBe HttpStatusCode.OK
                response.content shouldBe "[]"
            }

            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/id1")) {
                response.status() shouldBe HttpStatusCode.NotFound
            }
        }

        "push starts operation" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "-d", "1", "test") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "com.delphix.titan:remotes",
                    "test/foo") } returns "[{\"name\":\"remote\",\"provider\":\"nop\"}]"
            every { executor.exec("zfs", "list", "-Ho", "name,defer_destroy", "-t",
                    "snapshot", "-d", "2", "test/foo") } returns
                    "test/foo/guid@commit\toff"
            every { executor.exec("zfs", "list", "-Ho", "com.delphix.titan:metadata",
                    "test/foo/guid@commit") } returns "{}"

            val result = engine.handleRequest(HttpMethod.Post, "/v1/repositories/foo/remotes/remote/commits/commit/push") {
                addHeader(HttpHeaders.ContentType, ContentType.Application.Json.toString())
                setBody("{\"provider\":\"nop\"}")
            }
            result.response.status() shouldBe HttpStatusCode.OK
            val operation = gson.fromJson(result.response.content, Operation::class.java)

            operation.commitId shouldBe "commit"
            operation.remote shouldBe "remote"
            operation.operationType shouldBe Operation.OperationType.PUSH

            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/${operation.id}")) {
                response.status() shouldBe HttpStatusCode.OK
            }
        }

        "pull starts operation" {
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "test/foo") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "name,com.delphix.titan:metadata",
                    "-d", "1", "test") } returns "test/foo\t{}"
            every { executor.exec("zfs", "list", "-Ho", "com.delphix.titan:remotes",
                    "test/foo") } returns "[{\"name\":\"remote\",\"provider\":\"nop\"}]"
            every { executor.exec("zfs", "list", "-Ho", "name,defer_destroy", "-t",
                    "snapshot", "-d", "2", "test/foo") } returns ""

            val result = engine.handleRequest(HttpMethod.Post, "/v1/repositories/foo/remotes/remote/commits/commit/pull") {
                addHeader(HttpHeaders.ContentType, ContentType.Application.Json.toString())
                setBody("{\"provider\":\"nop\"}")
            }
            result.response.status() shouldBe HttpStatusCode.OK
            val operation = gson.fromJson(result.response.content, Operation::class.java)

            operation.commitId shouldBe "commit"
            operation.remote shouldBe "remote"
            operation.operationType shouldBe Operation.OperationType.PULL

            with(engine.handleRequest(HttpMethod.Get, "/v1/repositories/foo/operations/${operation.id}")) {
                response.status() shouldBe HttpStatusCode.OK
            }
        }
    }
}
