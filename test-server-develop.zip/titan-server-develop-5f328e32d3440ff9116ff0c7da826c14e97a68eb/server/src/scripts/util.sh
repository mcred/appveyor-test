#
# Copyright (c) 2019 by Delphix. All rights reserved.
#

#
# Primary delimiter for log messages. Lines that contain this delimiter (after the timestamp)
# will be processed by the CLI during log scanning.
#
log_delimiter=TITAN

#
# Return a timestamp to use in log messages and elsewhere.
#
function timestamp {
  date +"%F_%T"
}

#
# Log the beginning of the launch sequence. The CLi will search for the last indication of this
# message, and then consume all log messages until it sees an error or the launcher has started
# sucessfully.
#
function log_begin {
  local ts=$(timestamp)
  echo "$ts $log_delimiter BEGIN"
}

#
# Log the beginning of a step. This will be picked up by the CLI and displayed while the
# subsequent code is running, When a TITAN END message is received, then the CLI will display
# the step as completed and move on.
#
function log_start {
  local ts=$(timestamp)
  local msg=$1
  echo "$ts $log_delimiter START $msg"
}

#
# Log the end of a step. This will indicate to the CLI that it should stop waiting for the previous
# log_begin() to complete, and move on to the next step.
#
function log_end {
  local ts=$(timestamp)
  echo "$ts $log_delimiter END"
}

#
# Log an error. This will automatically exit the container with an error code, and the CLI will
# display the error prior to failing the command.
#
function log_error {
  local ts=$(timestamp)
  local msg=$1
  echo "$ts $log_delimiter ERROR $msg"
  exit 1
}
