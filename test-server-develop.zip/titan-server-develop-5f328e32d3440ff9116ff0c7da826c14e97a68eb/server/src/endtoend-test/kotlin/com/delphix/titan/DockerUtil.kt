/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan

import com.delphix.titan.util.CommandException
import com.delphix.titan.util.CommandExecutor
import khttp.get
import java.net.InetAddress

/**
 * Utility class for managing docker containers for integration tests. There are two types of
 * containers we care about: the titan server container and a remote SSH container. The titan
 * server is run on an alternate pool and port so as not to conflict with the running titan-server.
 * For the remote SSH server, we use 'rastasheep/ubuntu-sshd', which comes pre-built for remote access
 * over SSH.
 */
class DockerUtil(
    val identity: String = "test",
    val port: Int = 6001,
    val image: String = "titan:latest",
    val sshPort: Int = 6003
) {
    private val executor = CommandExecutor()
    private val retries = 10
    private val timeout = 1000L
    private var serverId: String? = null
    private var sshId: String? = null
    val sshHost: String
        get() = InetAddress.getLocalHost().hostAddress

    fun url(path: String): String {
        return "http://localhost:$port/v1/$path"
    }

    fun startServer() {
        /*
         * We ignore /system/build because we expect that the container will always have a matching
         * prebuilt kernel available. Otherwise, don't run integration tests there! If this cost
         * becomes problematic, we could load ZFS some other way and avoid the tax for each
         * end to end text invocation.
         */
        serverId = executor.exec("docker", "run", "--privileged", "--pid=host", "--network=host",
                "-d", "--restart", "always", "--name", "$identity-launch", "-v", "/lib:/titan/system",
                "-v", "/var/lib:/var/lib", "-v", "/run/docker:/run/docker",
                "-v", "/var/run/docker.sock:/var/run/docker.sock",
                "-e", "TITAN_IDENTITY=$identity", "-e", "TITAN_IMAGE=$image",
                "-e", "TITAN_PORT=$port", image, "/bin/bash", "/titan/launch"
        ).trim()
    }

    private fun testGet(): Int {
        try {
            val response = get(url("repositories"))
            return response.statusCode
        } catch (e: Exception) {
            return 500
        }
    }

    fun waitForServer() {
        var tried = 1
        while (testGet() != 200) {
            if (tried++ == retries) {
                throw Exception("Timed out waiting for server to start")
            }
            Thread.sleep(timeout)
        }
    }

    fun restartServer() {
        executor.exec("docker", "rm", "-f", "$identity-server")
    }

    fun stopServer(ignoreExceptions: Boolean = true) {
        try {
            executor.exec("docker", "rm", "-f", "$identity-launch")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
        try {
            executor.exec("docker", "rm", "-f", "$identity-server")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
        try {
            executor.exec("docker", "run", "--privileged", "--pid=host", "--network=host",
                    "-d", "--rm", "-v", "/lib:/titan/system",
                    "-v", "/var/lib:/var/lib", "-v", "/run/docker:/run/docker",
                    "-v", "/var/run/docker.sock:/var/run/docker.sock",
                    "-e", "TITAN_IDENTITY=$identity", "-e", "TITAN_IMAGE=$image",
                    "-e", "TITAN_PORT=$port", image, "/bin/bash", "/titan/teardown")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
    }

    fun writeFile(volume: String, filename: String, content: String) {
        val path = "/var/lib/$identity/mnt/$volume/$filename"
        // Using 'docker cp' can mess with volume mounts, leave this as simple as possible
        executor.exec("docker", "exec", "$identity-server", "sh", "-c",
                "echo \"$content\" > $path")
    }

    fun readFile(volume: String, filename: String): String {
        val path = "/var/lib/$identity/mnt/$volume/$filename"
        return executor.exec("docker", "exec", "$identity-server", "cat", path)
    }

    fun startSsh() {
        sshId = executor.exec("docker", "run", "-p", "$sshPort:22", "-d",
                "rastasheep/ubuntu-sshd:18.04").trim()
    }

    fun waitForSsh() {
    }

    fun stopSsh() {
        if (sshId != null) {
            executor.exec("docker", "rm", "-f", sshId!!)
        }
    }
}
