/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan

import com.delphix.titan.client.apis.RepositoriesApi
import com.delphix.titan.client.infrastructure.ClientException
import com.delphix.titan.models.Repository
import io.kotlintest.Spec
import io.kotlintest.TestCaseOrder
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec

class TeardownTest : StringSpec() {

    val dockerUtil = DockerUtil()
    val url = "http://localhost:${dockerUtil.port}"
    val repoApi = RepositoriesApi(url)

    override fun beforeSpec(spec: Spec) {
        dockerUtil.stopServer()
        dockerUtil.startServer()
        dockerUtil.waitForServer()
    }

    override fun afterSpec(spec: Spec) {
        dockerUtil.stopServer()
    }

    override fun testCaseOrder() = TestCaseOrder.Sequential

    init {
        "create new repository succeeds" {
            val repo = Repository(
                    name = "foo",
                    properties = mapOf("a" to "b")
            )
            repoApi.createRepository(repo)
        }

        "get created repository succeeds" {
            val repo = repoApi.getRepository("foo")
            repo.name shouldBe "foo"
        }

        "restarting server leaves repository intact" {
            dockerUtil.restartServer()
            dockerUtil.waitForServer()
            val repo = repoApi.getRepository("foo")
            repo.name shouldBe "foo"
        }

        "teardown and restart server should leave no repositories" {
            dockerUtil.stopServer(ignoreExceptions = false)
            dockerUtil.startServer()
            dockerUtil.waitForServer()
            shouldThrow<ClientException> {
                repoApi.getRepository("foo")
            }
        }
    }
}
