/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan

import io.kotlintest.specs.StringSpec

class RemoteWorkflowTest : StringSpec() {

    val dockerUtil = DockerUtil()

    init {
    }
}
