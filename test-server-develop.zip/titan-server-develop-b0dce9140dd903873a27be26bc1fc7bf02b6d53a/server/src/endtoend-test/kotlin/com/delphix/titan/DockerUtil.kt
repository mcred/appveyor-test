/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan

import com.delphix.titan.util.CommandException
import com.delphix.titan.util.CommandExecutor
import khttp.get

class DockerUtil(val identity: String = "test", val port: Int = 6001, val image: String = "titan:latest") {
    val executor = CommandExecutor()
    val retries = 10
    val timeout = 1000L
    var containerId: String? = null

    fun url(path: String): String {
        return "http://localhost:$port/v1/$path"
    }

    fun startDocker() {
        /*
         * We ignore /system/build because we expect that the container will always have a matching
         * prebuilt kernel available. Otherwise, don't run integration tests there! If this cost
         * becomes problematic, we could load ZFS some other way and avoid the tax for each
         * end to end text invocation.
         */
        containerId = executor.exec("docker", "run", "--privileged", "--pid=host", "--network=host",
                "-d", "--restart", "always", "--name", "$identity-launch", "-v", "/lib:/titan/system",
                "-v", "/var/lib:/var/lib", "-v", "/run/docker:/run/docker",
                "-v", "/var/run/docker.sock:/var/run/docker.sock",
                "-e", "TITAN_IDENTITY=$identity", "-e", "TITAN_IMAGE=$image",
                "-e", "TITAN_PORT=$port", image, "/bin/bash", "/titan/launch"
        ).trim()
    }

    fun testGet(): Int {
        try {
            val response = get(url("repositories"))
            return response.statusCode
        } catch (e: Exception) {
            return 500
        }
    }

    fun waitForServer() {
        var tried = 1
        while (testGet() != 200) {
            if (tried++ == retries) {
                throw Exception("Timed out waiting for server to start")
            }
            Thread.sleep(timeout)
        }
    }

    fun restartServer() {
        executor.exec("docker", "rm", "-f", "$identity-server")
    }

    fun stopDocker(ignoreExceptions: Boolean = true) {
        try {
            executor.exec("docker", "rm", "-f", "$identity-launch")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
        try {
            executor.exec("docker", "rm", "-f", "$identity-server")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
        try {
            executor.exec("docker", "run", "--privileged", "--pid=host", "--network=host",
                    "-d", "--rm", "-v", "/lib:/titan/system",
                    "-v", "/var/lib:/var/lib", "-v", "/run/docker:/run/docker",
                    "-v", "/var/run/docker.sock:/var/run/docker.sock",
                    "-e", "TITAN_IDENTITY=$identity", "-e", "TITAN_IMAGE=$image",
                    "-e", "TITAN_PORT=$port", image, "/bin/bash", "/titan/teardown")
        } catch (e: CommandException) {
            if (!ignoreExceptions) {
                throw e
            }
        }
    }

    fun writeFile(volume: String, filename: String, content: String) {
        val path = "/var/lib/$identity/mnt/$volume/$filename"
        // Using 'docker cp' can mess with volume mounts, leave this as simple as possible
        executor.exec("docker", "exec", "$identity-server", "sh", "-c",
                "echo \"$content\" > $path")
    }

    fun readFile(volume: String, filename: String): String {
        val path = "/var/lib/$identity/mnt/$volume/$filename"
        return executor.exec("docker", "exec", "$identity-server", "cat", path)
    }
}
