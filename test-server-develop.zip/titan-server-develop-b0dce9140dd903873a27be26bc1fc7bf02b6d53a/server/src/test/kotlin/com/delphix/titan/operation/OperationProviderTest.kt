/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.operation

import com.delphix.titan.ProviderModule
import com.delphix.titan.exception.NoSuchObjectException
import com.delphix.titan.exception.ObjectExistsException
import com.delphix.titan.models.Commit
import com.delphix.titan.models.EngineRequest
import com.delphix.titan.models.NopRemote
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.Operation
import com.delphix.titan.models.ProgressEntry
import com.delphix.titan.models.Repository
import com.delphix.titan.remote.nop.NopRemoteProvider
import com.delphix.titan.storage.zfs.ZfsStorageProvider
import com.delphix.titan.util.GuidGenerator
import io.kotlintest.TestCase
import io.kotlintest.TestCaseOrder
import io.kotlintest.TestResult
import io.kotlintest.shouldBe
import io.kotlintest.shouldThrow
import io.kotlintest.specs.StringSpec
import io.mockk.MockKAnnotations
import io.mockk.Runs
import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.impl.annotations.InjectMockKs
import io.mockk.impl.annotations.MockK
import io.mockk.impl.annotations.OverrideMockKs
import io.mockk.impl.annotations.SpyK
import io.mockk.just
import io.mockk.verify

class OperationProviderTest : StringSpec() {

    @SpyK
    var generator: GuidGenerator = GuidGenerator()

    @MockK
    lateinit var zfsStorageProvider: ZfsStorageProvider

    @SpyK
    var nopRemoteProvider = NopRemoteProvider()

    @InjectMockKs
    @OverrideMockKs
    var providers = ProviderModule("test")

    @InjectMockKs
    @OverrideMockKs
    lateinit var provider: OperationProvider

    override fun beforeTest(testCase: TestCase) {
        provider = OperationProvider(providers)
        return MockKAnnotations.init(this)
    }

    override fun afterTest(testCase: TestCase, result: TestResult) {
        clearAllMocks()
    }

    override fun testCaseOrder() = TestCaseOrder.Random

    fun addOperation(type: Operation.OperationType = Operation.OperationType.PULL) {
        provider.addOperation(OperationExecutor(providers,
                provider.buildOperation(type, "remote", "commit"),
                "foo", NopRemote(name = "remote"),
                NopRequest()))
    }

    init {
        "list operations for non-existent repository fails" {
            every { zfsStorageProvider.getRepository(any()) } throws NoSuchObjectException("")
            shouldThrow<NoSuchObjectException> {
                provider.listOperations("foo")
            }
        }

        "list operations returns empty list" {
            every { zfsStorageProvider.getRepository(any()) } returns Repository("foo")
            val result = provider.listOperations("foo")
            result.size shouldBe 0
        }

        "list operations returns list of current operations" {
            every { generator.get() } returns "id"
            addOperation()
            every { zfsStorageProvider.getRepository(any()) } returns Repository("foo")

            val result = provider.listOperations("foo")
            result.size shouldBe 1
            result[0].id shouldBe "id"
            result[0].remote shouldBe "remote"
            result[0].commitId shouldBe "commit"
        }

        "get operation fails for unknown operation" {
            shouldThrow<NoSuchObjectException> {
                provider.getOperation("repo", "id")
            }
        }

        "get operation should fail if known id but wrong repo" {
            every { generator.get() } returns "id"
            addOperation()
            shouldThrow<NoSuchObjectException> {
                provider.getOperation("bar", "id")
            }
        }

        "get operation succeeds" {
            every { generator.get() } returns "id"
            addOperation()
            val result = provider.getOperation("foo", "id")
            result.id shouldBe "id"
            result.remote shouldBe "remote"
            result.commitId shouldBe "commit"
        }

        "abort operation fails for unknown id" {
            shouldThrow<NoSuchObjectException> {
                provider.abortOperation("foo", "id")
            }
        }

        "abort operation succeeds" {
            every { generator.get() } returns "id"
            addOperation()
            provider.getOperation("foo", "id")
            provider.abortOperation("foo", "id")
        }

        "pull for non-existent remote fails" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf()
            shouldThrow<NoSuchObjectException> {
                provider.startPull("foo", "remote", "commit", NopRequest())
            }
        }

        "pull fails for mismatched remote fails" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            shouldThrow<IllegalArgumentException> {
                provider.startPull("foo", "remote", "commit", EngineRequest())
            }
        }

        "pull fails for non-existent remote commit" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { nopRemoteProvider.validateOperation(any(), any(), any()) } throws NoSuchObjectException("")
            shouldThrow<NoSuchObjectException> {
                provider.startPull("foo", "remote", "commit", NopRequest())
            }
        }

        "pull fails if local commit exists" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            shouldThrow<ObjectExistsException> {
                provider.startPull("foo", "remote", "commit", NopRequest())
            }
        }

        "pull succeeds" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            every { generator.get() } returns "id"
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.commitOperation("foo", "id", any()) } just Runs
            var op = provider.startPull("foo", "remote", "commit", NopRequest())
            op.id shouldBe "id"
            op.commitId shouldBe "commit"
            op.operationType shouldBe Operation.OperationType.PULL
            op.remote shouldBe "remote"
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.COMPLETE

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 4
            progress[0].type shouldBe ProgressEntry.Type.END
            progress[1].type shouldBe ProgressEntry.Type.START
            progress[1].message shouldBe "Running operation"
            progress[2].type shouldBe ProgressEntry.Type.END
            progress[3].type shouldBe ProgressEntry.Type.COMPLETE

            shouldThrow<NoSuchObjectException> {
                provider.getOperation("foo", op.id)
            }
        }

        "error during pull is reported correctly" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            every { generator.get() } returns "id"
            every { nopRemoteProvider.runOperation(any(), any()) } throws Exception("error")
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            var op = provider.startPull("foo", "remote", "commit", NopRequest())
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.FAILED

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 2
            progress[0].type shouldBe ProgressEntry.Type.END
            progress[0].message shouldBe "Pulling commit from 'remote'"
            progress[1].type shouldBe ProgressEntry.Type.FAILED
            progress[1].message shouldBe "error"
        }

        "interrupt during pull is reported correctly" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            every { generator.get() } returns "id"
            every { nopRemoteProvider.runOperation(any(), any()) } throws InterruptedException()
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            var op = provider.startPull("foo", "remote", "commit", NopRequest())
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.ABORTED

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 2
            progress[1].type shouldBe ProgressEntry.Type.ABORT
        }

        "pull fails if conflicting operation is in progress" {
            addOperation()
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            shouldThrow<ObjectExistsException> {
                provider.startPull("foo", "remote", "commit", NopRequest())
            }
        }

        "pull succeeds if non-conflicting operation is in progress" {
            addOperation(type = Operation.OperationType.PUSH)
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.commitOperation("foo", "id", any()) } just Runs
            var op = provider.startPull("foo", "remote", "commit2", NopRequest())
            provider.getExecutor("foo", op.id).join()
            provider.getOperation("foo", op.id)
        }

        "push for non-existent remote fails" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf()
            shouldThrow<NoSuchObjectException> {
                provider.startPush("foo", "remote", "commit", NopRequest())
            }
        }

        "push fails for mismatched remote fails" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            shouldThrow<IllegalArgumentException> {
                provider.startPush("foo", "remote", "commit", EngineRequest())
            }
        }

        "push fails if local commit cannot be found" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } throws NoSuchObjectException("")
            shouldThrow<NoSuchObjectException> {
                provider.startPush("foo", "remote", "commit", NopRequest())
            }
        }

        "push fails if remote commit exists" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            every { nopRemoteProvider.validateOperation(any(), any(), any()) } throws ObjectExistsException("")
            shouldThrow<ObjectExistsException> {
                provider.startPush("foo", "remote", "commit", NopRequest())
            }
        }

        "push succeeds" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            every { generator.get() } returns "id"
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            var op = provider.startPush("foo", "remote", "commit", NopRequest())
            op.id shouldBe "id"
            op.commitId shouldBe "commit"
            op.operationType shouldBe Operation.OperationType.PUSH
            op.remote shouldBe "remote"
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.COMPLETE

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 4
            progress[0].type shouldBe ProgressEntry.Type.END
            progress[0].message shouldBe "Pushing commit to 'remote'"
            progress[1].type shouldBe ProgressEntry.Type.START
            progress[1].message shouldBe "Running operation"
            progress[2].type shouldBe ProgressEntry.Type.END
            progress[3].type shouldBe ProgressEntry.Type.COMPLETE

            shouldThrow<NoSuchObjectException> {
                provider.getOperation("foo", op.id)
            }
        }

        "error during push is reported correctly" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            every { generator.get() } returns "id"
            every { nopRemoteProvider.runOperation(any(), any()) } throws Exception("error")
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            var op = provider.startPush("foo", "remote", "commit", NopRequest())
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.FAILED

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 2
            progress[0].type shouldBe ProgressEntry.Type.END
            progress[0].message shouldBe "Pushing commit to 'remote'"
            progress[1].type shouldBe ProgressEntry.Type.FAILED
            progress[1].message shouldBe "error"
        }

        "interrupt during push is reported correctly" {
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            every { generator.get() } returns "id"
            every { nopRemoteProvider.runOperation(any(), any()) } throws InterruptedException("error")
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            var op = provider.startPush("foo", "remote", "commit", NopRequest())
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.ABORTED

            val progress = provider.getProgress("foo", op.id)
            progress.size shouldBe 2
            progress[0].type shouldBe ProgressEntry.Type.END
            progress[1].type shouldBe ProgressEntry.Type.ABORT
        }

        "push fails if conflicting operation is in progress" {
            addOperation(type = Operation.OperationType.PUSH)
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit")
            shouldThrow<ObjectExistsException> {
                provider.startPush("foo", "remote", "commit", NopRequest())
            }
        }

        "push succeeds if non-conflicting operation is in progress" {
            addOperation(type = Operation.OperationType.PUSH)
            every { zfsStorageProvider.getRemotes(any()) } returns listOf(NopRemote(name = "remote"))
            every { zfsStorageProvider.getCommit(any(), any()) } returns Commit(id = "commit2")
            every { generator.get() } returns "id"
            every { zfsStorageProvider.discardOperation("foo", "id") } just Runs
            every { zfsStorageProvider.createOperation("foo", any()) } just Runs
            var op = provider.startPush("foo", "remote", "commit2", NopRequest())
            provider.getExecutor("foo", op.id).join()
            op = provider.getOperation("foo", op.id)
            op.state shouldBe Operation.State.COMPLETE

            verify {
                zfsStorageProvider.discardOperation("foo", "id")
            }
        }

        // TODO load failed operations test
    }
}
