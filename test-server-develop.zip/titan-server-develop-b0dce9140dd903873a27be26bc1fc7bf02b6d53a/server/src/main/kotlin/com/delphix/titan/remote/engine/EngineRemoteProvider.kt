/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.remote.engine

import com.delphix.titan.ProviderModule
import com.delphix.titan.models.Commit
import com.delphix.titan.models.Operation
import com.delphix.titan.models.Remote
import com.delphix.titan.operation.OperationExecutor
import com.delphix.titan.remote.RemoteProvider

class EngineRemoteProvider : RemoteProvider {
    override fun addRemote(remote: Remote) {
        throw NotImplementedError() // TODO
    }

    override fun removeRemote(remote: Remote) {
        throw NotImplementedError() // TODO
    }

    override fun updateRemote(old: Remote, new: Remote) {
        throw NotImplementedError() // TODO
    }

    override fun listCommits(remote: Remote): List<Commit> {
        throw NotImplementedError() // TODO
    }

    override fun getCommit(remote: Remote, commitId: String): Commit {
        throw NotImplementedError() // TODO
    }

    override fun validateOperation(remote: Remote, comitId: String, opType: Operation.OperationType) {
        throw NotImplementedError() // TODO
    }

    override fun runOperation(providers: ProviderModule, operation: OperationExecutor) {
        throw NotImplementedError() // TODO
    }
}
