/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.remote.nop

import com.delphix.titan.ProviderModule
import com.delphix.titan.models.Commit
import com.delphix.titan.models.NopRequest
import com.delphix.titan.models.Operation
import com.delphix.titan.models.ProgressEntry
import com.delphix.titan.models.Remote
import com.delphix.titan.operation.OperationExecutor
import com.delphix.titan.remote.RemoteProvider

/**
 * The nop (No-operation) is a special provider used for internal testing to make it easier to
 * test local workflows without having to mock out an external remote provider. As its name implies,
 * this will simply ignore any operations. Pushing and pulling will always succeed, though listing
 * remotes will always return an empty list.
 */
class NopRemoteProvider : RemoteProvider {
    override fun addRemote(remote: Remote) {
        // No-op
    }

    override fun removeRemote(remote: Remote) {
        // No-op
    }

    override fun updateRemote(old: Remote, new: Remote) {
        // No-op
    }

    override fun listCommits(remote: Remote): List<Commit> {
        return listOf()
    }

    override fun getCommit(remote: Remote, commitId: String): Commit {
        return Commit(id = commitId, properties = mapOf())
    }

    override fun validateOperation(remote: Remote, comitId: String, opType: Operation.OperationType) {
        // All operations always succeed
    }

    override fun runOperation(providers: ProviderModule, operation: OperationExecutor) {
        operation.addProgress(ProgressEntry(ProgressEntry.Type.START, "Running operation"))
        val request = operation.request as NopRequest
        if (request.delay != 0) {
            Thread.sleep(request.delay * 1000L)
        }
        operation.addProgress(ProgressEntry(ProgressEntry.Type.END))
    }
}
