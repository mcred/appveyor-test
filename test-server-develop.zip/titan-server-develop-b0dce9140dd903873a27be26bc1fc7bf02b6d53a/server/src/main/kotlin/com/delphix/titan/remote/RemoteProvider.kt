/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.remote

import com.delphix.titan.ProviderModule
import com.delphix.titan.models.Commit
import com.delphix.titan.models.Operation
import com.delphix.titan.models.Remote
import com.delphix.titan.operation.OperationExecutor

interface RemoteProvider {
    fun addRemote(remote: Remote)
    fun removeRemote(remote: Remote)
    fun updateRemote(old: Remote, new: Remote)
    fun listCommits(remote: Remote): List<Commit>
    fun getCommit(remote: Remote, commitId: String): Commit

    fun validateOperation(remote: Remote, comitId: String, opType: Operation.OperationType)
    fun runOperation(providers: ProviderModule, operation: OperationExecutor)
}
