/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package com.delphix.titan.util

import org.slf4j.LoggerFactory
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Handle invocation of external commands. This is a wrapper around the native interfaces that
 * handles all of the stdin/stdout errors, and will throw an exception if the command returns
 * a non-zero exit status. It is also a convenient to mock out any dependencies on the external
 * system.
 */
class CommandExecutor(val timeout: Long = 60) {

    companion object {
        val log = LoggerFactory.getLogger(CommandExecutor::class.java)
    }

    /**
     * Execute the given command. Throws an exception if the
     */
    fun exec(vararg args: String): String {
        val builder = ProcessBuilder()
        builder.command(*args)
        val process = builder.start()
        try {
            process.waitFor(timeout, TimeUnit.SECONDS)
            val output = process.inputStream.bufferedReader().readText()
            val argString = args.joinToString()
            if (process.isAlive) {
                log.error("Timeout: $argString")
                throw IOException("Timed out waiting for command: $args")
            }
            if (process.exitValue() != 0) {
                log.error("Exit ${process.exitValue()}: $argString")
                val errOutput = process.errorStream.bufferedReader().readText()
                throw CommandException("Command failed: $args",
                        exitCode = process.exitValue(),
                        output = errOutput)
            }
            log.info("Success: $argString")
            return output
        } finally {
            process.destroy()
        }
    }
}
