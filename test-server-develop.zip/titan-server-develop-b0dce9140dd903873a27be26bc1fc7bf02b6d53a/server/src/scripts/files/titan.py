from flask import Flask, jsonify, request
import json
import logging
import subprocess
import uuid
import os
import pprint
from datetime import datetime
import dateutil.parser

app = Flask(__name__)
app.logger.setLevel(logging.DEBUG)
pool = 'titan'
mountroot = '/var/lib/{}/mnt'.format(pool)

class verbose_logging(object):
    def __init__(self, app):
        self._app = app

    def __call__(self, environ, resp):
        errorlog = environ['wsgi.errors']
        pprint.pprint(('REQUEST', environ), stream=errorlog)

        def log_response(status, headers, *args):
            pprint.pprint(('RESPONSE', status, headers), stream=errorlog)
            return resp(status, headers, *args)

        return self._app(environ, log_response)

def verbose_jsonify(object):
    app.logger.info(object)
    return jsonify(object)

def verbose_json():
    body = request.get_json(force=True)
    app.logger.info(body)
    return body

def run_zfs_command(args):
    try:
        app.logger.info(args)
        return subprocess.check_output(['zfs'] + args, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as e:
        raise Exception('ZFS command failed: {}'.format(e.output))

def get_active_dataset(name):
    guid = run_zfs_command(['get', '-Ho', 'value', 'com.delphix.titan:active', '{}/{}'.format(pool, name)])
    return '{}/{}/{}'.format(pool, name, guid.strip())

def get_volume_dataset(name):
    components = name.split('/')
    if len(components) != 2:
        raise Exception('dataset name "{}" must be of the form "<repo>/<volume>"'.format(name))
    return "{}/{}".format(get_active_dataset(components[0]), components[1])

@app.route('/Titan.CreateRepository', methods=['POST'])
def titan_repo_create():
    body = verbose_json()
    name = body['name']
    guid = str(uuid.uuid4())
    app.logger.info("Create Repository {} ({})".format(name, guid))
    run_zfs_command(['create', '-o', 'mountpoint=legacy', '-o', 'com.delphix.titan:active={}'.format(guid), '{}/{}'.format(pool, name)])
    run_zfs_command(['create', '{}/{}/{}'.format(pool, name, guid)])
    run_zfs_command(['snapshot', '-o', 'com.delphix.titan:metadata={}', '{}/{}/{}@initial'.format(pool, name, guid)])
    return verbose_jsonify({'guid': guid})

@app.route('/Titan.DestroyRepository', methods=['POST'])
def titan_repo_destroy():
    name = verbose_json()['name']
    run_zfs_command(['destroy', '-r', '{}/{}'.format(pool, name)])
    return verbose_jsonify({})

@app.route('/Titan.List', methods=['POST'])
def titan_repo_list():
    output = run_zfs_command(['list', '-Ho', 'name,com.delphix.titan:metadata', '-d', '1', pool])
    ret = []
    for line in output.splitlines():
        fields = line.strip().split("\t",1)
        dataset = fields[0]
        metadata_string = fields[1]
        components = dataset.split('/')
        if metadata_string == "-":
            metadata = {}
        else:
            metadata = json.loads(metadata_string)
        if len(components) == 2:
            ret.append({
                'name': components[1],
                'metadata': metadata
                })
    return verbose_jsonify(ret)

@app.route('/Titan.Get', methods=['POST'])
def titan_repo_get():
    name = verbose_json()['name']
    output = run_zfs_command(['list', '-Ho', 'com.delphix.titan:metadata', '{}/{}'.format(pool, name)])
    if len(output) == 0:
        raise Exception('no such dataset {}'.format(name))
    if output == "-":
        metadata = {}
    else:
        metadata = json.loads(output)
    return verbose_jsonify({
        'name': name,
        'metadata': metadata
        })

@app.route('/Titan.Update', methods=['POST'])
def titan_repo_update():
    body = verbose_json()
    name = body['name']
    if 'metadata' in body:
        metadata = body['metadata']
    else:   
        metadata = {}
    run_zfs_command(['set', 'com.delphix.titan:metadata={}'.format(json.dumps(metadata)), '{}/{}'.format(pool, name)])
    return verbose_jsonify({
        'name': name,
        'metadata': body['metadata']
        })

@app.route('/Titan.Commit', methods=['POST'])
def titan_repo_commit():
    body = verbose_json()
    name = body['name']
    dataset = get_active_dataset(name)
    args = ['snapshot', '-r']
    if "metadata" in body and body["metadata"] != "":
        if "\t" in body["metadata"]:
            raise Exception("snapshot metadata cannot have tabs")
        metadata = body["metadata"]
    else:
        metadata = {}
    args += [ '-o', 'com.delphix.titan:metadata={}'.format(json.dumps(metadata))]
    guid = str(uuid.uuid4())
    args += [ '{}@{}'.format(dataset, guid) ]
    run_zfs_command(args)
    creation = run_zfs_command(['list', '-Hpo', 'creation', '{}@{}'.format(dataset, guid)]).strip()
    metadata["timestamp"] = datetime.fromtimestamp(int(creation)).isoformat()
    run_zfs_command(["set", 'com.delphix.titan:metadata={}'.format(json.dumps(metadata)), '{}@{}'.format(dataset, guid)])
    return verbose_jsonify({
        'hash': guid
        })



@app.route('/Titan.Log', methods=['POST'])
def titan_repo_log():
    body = verbose_json()
    name = body['name']
    output = run_zfs_command(['list', '-Hpo', 'name,com.delphix.titan:metadata', '-t', 'snapshot', '-d', '2', '{}/{}'.format(pool, name)])
    ret = []
    for line in output.splitlines():
        fields = line.strip().split("\t")
        components = fields[0].split("@")
        if fields[1] != "-":
            metadata = json.loads(fields[1])
            if "timestamp" in metadata:
                obj = {
                    "hash": components[1],
                    "metadata": metadata
                }
                ret.append(obj)
    ret.sort(key=lambda r: dateutil.parser.parse(r["metadata"]["timestamp"]), reverse=True)
    return verbose_jsonify(ret)

def create_clone(name, hash, guid=None):
    output = run_zfs_command(['list', '-Hpo', 'name', '-t', 'snapshot', '-d', '2', '{}/{}'.format(pool, name)])
    dataset = None
    for line in output.splitlines():
        components = line.strip().split("@")
        if components[1] == hash:
            dataset = components[0]
            break

    if not dataset:
        raise Exception("unknown commit {}".format(hash))

    if not guid:
        guid = str(uuid.uuid4())
    run_zfs_command(['create', '{}/{}/{}'.format(pool, name, guid)])

    output = run_zfs_command(['list', '-rHo', 'name', dataset])
    for line in output.splitlines():
        source = line.strip()
        components = source.split("/")
        app.logger.info(components)
        if len(components) == 4:
            newdataset = "{}/{}/{}/{}".format(pool, name, guid, components[3])
            run_zfs_command(['clone', '{}@{}'.format(source, hash), newdataset])

    return guid

@app.route('/Titan.Abort', methods=['POST'])
def titan_operation_abort():
    body = verbose_json()
    name = body['name']
    guid = body['operation']
    try:
        run_zfs_command(['destroy', '-r', '{}/{}/{}'.format(pool, name, guid)])
    except Exception:
        print("dataset doesn't exist, ignoring abort")
    return verbose_jsonify({})

@app.route('/Titan.Push', methods=['POST'])
def titan_repo_push():
    body = verbose_json()
    name = body['name']
    hash = body['hash']
    guid = body['operation']
    dataset = '{}/{}/{}'.format(pool, name, guid)
    try:
        run_zfs_command(['list', dataset])
    except Exception:
        create_clone(name, hash, guid)

    user = body['username']
    address = body['address']

    basemount = '{}/{}'.format(mountroot, guid)
    mountpoint = '{}/mnt'.format(basemount)
    subprocess.check_output(['mkdir', '-p', mountpoint])
    keypath = '{}/key'.format(basemount)
    f = open(keypath, "w")
    f.write(body['key'])
    f.close()
    os.chmod(keypath, 0600)

    output = run_zfs_command(['list', '-rHo', 'name', dataset])
    result = ''
    for line in output.splitlines():
        components = line.strip().split("/")
        if len(components) == 4:
            app.logger.info('syncing {}'.format(line.strip()))
            subprocess.check_output(['mount', '-t', 'zfs', line.strip(), mountpoint])

            try:
                dst = "{}@{}:data/{}".format(user, address, components[3])
                cmd = ['rsync', '-e', 'ssh -p 8022 -o StrictHostKeyChecking=no -i {}'.format(keypath),
                    '--rsync-path=sudo rsync', '--info=stats1', '--inplace', '--delete', '-raz', '{}/'.format(mountpoint), dst]
                app.logger.info(cmd)
                result = subprocess.check_output(cmd)
            finally:
                subprocess.check_output(['umount', mountpoint])

    subprocess.check_output(['rm', '-rf', basemount])
    run_zfs_command(['destroy', '-r', '{}/{}/{}'.format(pool, name, guid)])

    return verbose_jsonify({ 'output': result })


@app.route('/Titan.Pull', methods=['POST'])
def titan_repo_pull():
    body = verbose_json()
    name = body['name']
    guid = body['operation']
    hash = body['hash']
    dataset = '{}/{}/{}'.format(pool, name, guid)
    try:
        run_zfs_command(['list', dataset])
    except Exception:
        create_clone(name, "initial", guid) # TODO find appropriate source hash, not just initial

    user = body['username']
    address = body['address']

    basemount = '{}/{}'.format(mountroot, guid)
    mountpoint = '{}/mnt'.format(basemount)
    subprocess.check_output(['mkdir', '-p', mountpoint])
    keypath = '{}/key'.format(basemount)
    f = open(keypath, "w")
    f.write(body['key'])
    f.close()
    os.chmod(keypath, 0600)

    output = run_zfs_command(['list', '-rHo', 'name', dataset])
    result = ''
    for line in output.splitlines():
        components = line.strip().split("/")
        if len(components) == 4:
            app.logger.info('syncing {}'.format(line.strip()))
            subprocess.check_output(['mount', '-t', 'zfs', line.strip(), mountpoint])

            try:
                dst = "{}@{}:data/{}/".format(user, address, components[3])
                cmd = ['rsync', '-e', 'ssh -p 8022 -o StrictHostKeyChecking=no -i {}'.format(keypath),
                    '--rsync-path=sudo rsync', '--info=stats1', '--inplace', '--delete', '-raz', dst, '{}/'.format(mountpoint)]
                app.logger.info(cmd)
                result = subprocess.check_output(cmd)
            finally:
                subprocess.check_output(['umount', mountpoint])

    subprocess.check_output(['rm', '-rf', basemount])
    run_zfs_command(['snapshot', '-r', '-o', 'com.delphix.titan:metadata={}'.format(json.dumps(body['metadata'])), '{}/{}/{}@{}'.format(pool, name, guid, hash)])

    return verbose_jsonify({ 'output': result })


@app.route('/Titan.Checkout', methods=['POST'])
def titan_repo_checkout():
    body = verbose_json()
    name = body['name']
    hash = body['hash']
    guid = create_clone(name, hash)
    run_zfs_command(['set', 'com.delphix.titan:active={}'.format(guid), '{}/{}'.format(pool, name)])
    return verbose_jsonify({})

@app.route('/Plugin.Activate', methods=['POST'])
def plugin_activate():
    return verbose_jsonify({'Implements': ['VolumeDriver']})

@app.route('/VolumeDriver.Create', methods=['POST'])
def volume_create():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    path = body['Opts']['path']
    app.logger.info("Create {} ({})".format(name, dataset))
    try:
        subprocess.check_output(['zfs', 'create', '-o', 'com.delphix.titan:path={}'.format(path), dataset], stderr=subprocess.STDOUT)
        subprocess.check_output(['zfs', 'snapshot', '{}@initial'.format(dataset)], stderr=subprocess.STDOUT)
        subprocess.check_output(['mkdir', '-p', '{}/{}'.format(mountroot, name)])
    except subprocess.CalledProcessError as e:
        return verbose_jsonify({'Err': e.output})
    return verbose_jsonify({'Err': ''})

@app.route('/VolumeDriver.Remove', methods=['POST'])
def volume_remove():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    app.logger.info("Remove {} ({})".format(name, dataset))
    try:
        subprocess.check_output(['zfs', 'destroy', '-r', dataset], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        return verbose_jsonify({'Err': e.output})
    return verbose_jsonify({'Err': ''})

@app.route('/VolumeDriver.Mount', methods=['POST'])
def volume_mount():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    app.logger.info("Mount {} ({})".format(name, dataset))
    mountpoint = '{}/{}'.format(mountroot, name)
    try:
        subprocess.check_output(['mount', '-t', 'zfs', dataset, mountpoint])
    except subprocess.CalledProcessError as e:
        return verbose_jsonify({'Err': e.output})
    return verbose_jsonify({
        'Mountpoint': mountpoint,
        'Err': ''
        })

@app.route('/VolumeDriver.Path', methods=['POST'])
def volume_path():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    app.logger.info("Path {} ({})".format(name, dataset))
    return verbose_jsonify({
        'Mountpoint': '{}/{}'.format(mountroot, name),
        'Err': ''
        })

@app.route('/VolumeDriver.Unmount', methods=['POST'])
def volume_unmount():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    app.logger.info("Unmount {} ({})".format(name, dataset))
    try:
        subprocess.check_output(['umount', '{}/{}'.format(mountroot, name)])
    except subprocess.CalledProcessError as e:
        if "not mounted" not in e.output:
            return verbose_jsonify({'Err': e.output})
    return verbose_jsonify({'Err': ''})

@app.route('/VolumeDriver.Get', methods=['POST'])
def volume_get():
    body = verbose_json()
    name = body['Name']
    dataset = get_volume_dataset(name)
    app.logger.info("Get {} ({})".format(name, dataset))

    # Ensure dataset exists
    try:
        subprocess.check_output(['zfs', 'list', dataset])
    except subprocess.CalledProcessError as e:
        return verbose_jsonify({
            'Err': 'No such dataset {}'.format(dataset)
            })

    return verbose_jsonify({
        'Volume': {
            'Name': name,
            'Mountpoint': '{}/{}'.format(mountroot, name),
            'Status': {}
        },
        'Err': ''
        })

@app.route('/VolumeDriver.List', methods=['POST'])
def volume_list():
    volumes = []
    try:
        filesystems = subprocess.check_output(['zfs', 'list', '-Ho', 'name', '-r', pool], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        return verbose_jsonify({'Err': e.output})
    seen = {}
    for line in filesystems.splitlines():
        values = line.strip().split()
        components = values[0].split('/')
        if len(components) != 4:
            continue
        name = "{}/{}".format(components[1], components[3])
        if name in seen:
            continue
        seen[name] = True
        volumes.append({
            'Name': name,
            'Mountpoint': '{}/{}'.format(mountroot, name)
            })
    return verbose_jsonify({
        'Volumes': volumes,
        'Err': ''
        })

@app.route('/VolumeDriver.Capabilities', methods=['POST'])
def volume_capabilities():
    return verbose_jsonify({
        "Capabilities": {
            "Scope": "local"
        }
    })

if __name__ == '__main__':
    app.logger.info("Running App")
    # app.wsgi_app = verbose_logging(app.wsgi_app)
    app.run(debug=True, host='0.0.0.0')
