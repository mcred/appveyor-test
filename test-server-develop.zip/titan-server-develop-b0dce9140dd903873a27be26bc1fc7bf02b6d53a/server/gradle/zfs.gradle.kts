
var zfsVersion = "0.8.1"
var zfsDefaultUname = "4.9.125-linuxkit"
var zfsBuilder = "delphix/zfs-builder:latest"

var getZfsConfig = tasks.register<Exec>("getZfsConfig") {
    group = "ZFS"
    description = "Copy kernel configuration from docker VM"
    val output = "/build/\$(uname -r)"
    commandLine("docker", "run", "--rm", "-v", "${project.projectDir}/zfs/config:/build",
            "${zfsBuilder}", "sh", "-c",
            "mkdir $output && cp /proc/config.gz $output && chmod 644 $output/config.gz")
}

var compileZfsUserland = tasks.register<Exec>("compileZfsUserland") {
    group = "ZFS"
    description = "Compile ZFS userland"
    var uname = zfsDefaultUname
    if (project.hasProperty("uname")) {
        uname = project.property("uname").toString()
    }
    // We cannot use output.dir() due to dangling symlinks in the ZFS build
    // https://github.com/gradle/gradle/issues/1365
    project.file("${buildDir}/zfs/${uname}").mkdirs();
    commandLine("docker", "run", "--rm",
            "-v", "${buildDir}/zfs/${uname}:/build",
            "-v", "${project.projectDir}/zfs/config/${uname}:/config",
            "-e", "ZFS_VERSION=zfs-${zfsVersion}",
            "-e", "KERNEL_RELEASE=${uname}",
            "-e", "ZFS_CONFIG=user",
            "${zfsBuilder}")
}

var buildZfsUserland = tasks.register<Copy>("buildZfsUserland") {
    group = "ZFS"
    description = "Build ZFS userland binaries to be checked into the source tree"
    var uname = zfsDefaultUname
    if (project.hasProperty("uname")) {
        uname = project.property("uname").toString()
    }
    from("${buildDir}/zfs/${uname}")
    into("${project.projectDir}/zfs/userland")
    include("sbin/**")
    exclude("sbin/zdb")
    exclude("sbin/ztest")
    include("lib/**")
    exclude("lib/modules/**")
    exclude("lib/udev/**")
    exclude("lib/libzpool.*")
    dependsOn(compileZfsUserland)
}

var compileZfsKernel = tasks.register<Exec>("compileZfsKernel") {
    group = "ZFS"
    description = "Compile ZFS from default kernel version"
    var uname = zfsDefaultUname
    if (project.hasProperty("uname")) {
        uname = project.property("uname").toString()
    }
    // We cannot use output.dir() due to dangling symlinks in the ZFS build
    // https://github.com/gradle/gradle/issues/1365
    project.file("${buildDir}/zfs/${uname}").mkdirs();
    commandLine("docker", "run", "--rm",
            "-v", "${buildDir}/zfs/${uname}:/build",
            "-v", "${project.projectDir}/zfs/config/${uname}:/config",
            "-e", "ZFS_VERSION=zfs-${zfsVersion}",
            "-e", "KERNEL_RELEASE=${uname}",
            "-e", "ZFS_CONFIG=kernel",
            "${zfsBuilder}")
}


var buildZfsKernel = tasks.register<Tar>("buildZfsKernel") {
    group = "ZFS"
    description = "Build ZFS kernel archive to be checked into the source tree"
    var uname = zfsDefaultUname
    if (project.hasProperty("uname")) {
        uname = project.property("uname").toString()
    }

    archiveFileName.set("${uname}.tar.gz")
    destinationDirectory.set(file("${project.projectDir}/zfs/kernel"))
    compression = Compression.GZIP

    from("${buildDir}/zfs/${uname}")
    include("lib/modules/**")
    dependsOn(compileZfsKernel)
}
