rootProject.name = "titan"

val titanVersion = "0.2.0"

include("client")
include("server")
