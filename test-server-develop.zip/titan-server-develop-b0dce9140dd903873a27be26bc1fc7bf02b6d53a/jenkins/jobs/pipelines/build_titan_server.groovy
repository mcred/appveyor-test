/*
 * Copyright (c) 2017, 2019 by Delphix. All rights reserved.
 */

currentBuild.displayName = "#${env.BUILD_NUMBER}"
currentBuild.result = 'SUCCESS'

timestamps {
  timeout(time: 30, unit: 'MINUTES') {
    try {

      node('misc') {
        def venvPath = "${env.WORKSPACE}/venv"
        stage('Checkout') {
          checkout([$class: 'GitSCM',
            userRemoteConfigs: [
              [name: 'origin', url: env.GIT_URL, credentialsId: 'git-ci-key']
            ],
            branches: [[name: env.GIT_BRANCH]],
            extensions: [
              [$class: 'CloneOption', shallow: false, timeout: 60],
              [$class: 'WipeWorkspace']
            ]])
        }

        stage('Build'){ sh(script: './gradlew check assemble') }

        stage('PublishClient'){
          withCredentials([
            usernamePassword(credentialsId: 'orbital-publisher', usernameVariable: 'ARTIFACTORY_USERNAME',
            passwordVariable: 'ARTIFACTORY_PASSWORD')
          ]) {
            if(!params.DRY_RUN){
              sh(script: """
                    ./gradlew client:publish -DARTIFACTORY_USERNAME=${ARTIFACTORY_USERNAME} -DARTIFACTORY_PASSWORD=${ARTIFACTORY_PASSWORD}
                    """.stripIndent())
            }
          }
        }
        stage('PublishDockerHub'){
          withCredentials([
            usernamePassword(credentialsId: 'delphixautomation', usernameVariable: 'DOCKERHUB_USERNAME',
            passwordVariable: 'DOCKERHUB_PASSWORD')
          ]) {
            if(!params.DRY_RUN){
              sh(script: """
                    docker login -u="${DOCKERHUB_USERNAME}" -p="${DOCKERHUB_PASSWORD}" && \
                    ./gradlew server:publish && \
                    docker logout
                    """.stripIndent())
            }
          }
        }
      }
    } catch (err) {
      currentBuild.result = 'FAILURE'
      throw err
    } finally {
      if (currentBuild.result != 'SUCCESS') {
        def slackChannel = System.getenv('JENKINS_DEVELOPER') ? '#slacktest' : "#titan-alerts"
        def msg = currentBuild.result + ": Job '${env.JOB_BASE_NAME} [${env.BUILD_NUMBER}]' (${env.BUILD_URL})"
        slackSend(channel: slackChannel,
        color: currentBuild.result == 'SUCCESS' ? 'good' : 'danger',
        message: msg,
        token: 'O18kjCFodIAfqTgRi8dXAXDA',
        teamDomain: 'delphix')
      }
    }
  }
}
