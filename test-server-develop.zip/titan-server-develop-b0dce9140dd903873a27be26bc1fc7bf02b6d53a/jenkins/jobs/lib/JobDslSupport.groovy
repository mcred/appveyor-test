/*
 * Copyright (c) 2019 by Delphix. All rights reserved.
 */

package lib

class JobDslSupport {
  /*
   * When using the scm() trigger this default value should be used as the cron string. Our Git hooks will notify
   * Jenkins of pushes to all gates; however it is possible for these notifications to be missed (e.g. if Jenkins is
   * down when they are sent). To make sure SCM changes are still picked up in a timely manner we also have Jenkins
   * check for changes periodically.
   */
  def static SCM_CRON = "H/15 * * * *"

  /*
   * This function takes as input a short branch name (i.e. 'master' not 'refs/heads/master' or 'origin/master')
   * and returns true if the branch is a "shipping" branch as opposed to a temporary or project branch.
   *
   * This function should be used to restrict expensive jobs to only run automatically on "shipping" branches.
   * For example, if we have many regression testing jobs scheduled by cron strings we do not want to run every
   * regression test on every project branch on the same schedule.
   *
   * Note that scripts jobs are not required to skip creating expensive jobs on project branches, just
   * scheduling them to run automatically.  A common pattern might be:
   *
   * if (isShippingBranch(branchName)) {
   *     triggers {
   *         scm("H/5 * * * *")
   *     }
   * }
   *
   * This allows the job to exist and be manually runnable for any branch, but avoids running it on every push
   * to the branch.
   */
  def static isShippingBranch(String branchName) {
    if (branchName.equals("master")) {
      return true
    } else if (branchName ==~ /[0-9]\.[0-9]\/(stage|release)/) {
      return true
    } else {
      return false
    }
  }

  /*
   * Returns true if this Jenkins instance was started by a developer (as opposed to a master production
   * instance). This should be used to restrict jobs to not be automatically triggered on developer instances.
   */
  def static isDeveloperJenkinsInstance() {
    return System.getenv('JENKINS_DEVELOPER') != null
  }
}
