# Titan Docker Server

This repository contains the docker container that is used by the titan CLI.

The overall architecture looks like the following:

![architecture](./img/architecture.png)

## Container architecture

The underlying architecture can be a bit complex due to the intricacies of docker and ZFS. Our goal is
to be able to spin up a container that acts as docker volume plugin and has ZFS access to the docker host
VM (typically running inside of Windows or MacOS). To do this, we need to have a `launcher` container
that is then responsible for running the actual server. The reason for this is that we need to perform
bind mounts from the docker VM to the container, so we can access system namespaces such as docker
plugins and ZFS directories. But if we just execute `docker run` from, say, MacOS, our volume bind mounts
will actually be to the MacOS system, not the docker VM.

We also need to create the ability to run ZFS commands within the server container. We take advantage
of the fact that the docker host VM is Ubuntu and can have the ZFS modules loaded. Unfortunately, knowing
exactly what modules to load can be tricky, so we tap into the work that dotmesh.io has done to pull
the right ZFS modules down. In fact, we copy most of their require_zfs script as our launcher. This 
creates an external dependency on packages delivered by a third party, but that's sufficient for the
research portion of this work.

To minimize the image overhead, we actually build a single image (`titan`), and then enable it to be run
with one of two entry points: `launch.sh` or `server.sh`. This determines the role, and we name the
containers `titan-launch` and `titan-server`, respectively.

## ZFS architecture

All of the ZFS filesystems are stored within the `titan` pool that is created by the launch container.
We therefore start with a single filesystem that is the root of our repository:

    titan/<repo>

The next thing we have to deal with is that we want to swap out the data state for this logical volume
without having to change the name, since it remains attached to the container. For this reason, we
assign every active filesystem state, called an instance, its own GUID:

    titan/<repo>/<guid>

We then set a ZFS user property on the repository (`com.delphix.titan:active`) that indicates the
currently active GUID. Any attempt to get info, mount, unmount, etc this logical volume will first
lookup that active path and redirect to that filesystem.

But docker containers can also contain multiple volumes. Ideally, we'd want to just treat these as
simple subdirectories, but docker doesn't allow for mounting of filesystems within volumes. And while
we could create some kind of namespace that maps many paths back to one filesystem, this creates
a level of complexity that isn't warranted given that ZFS can manage trees of filesystems easily.
The resulting tree looks like:

    titan/<repo>/<guid>/<vol>

The client is responsible for running the container on top of the given volumes. When we want to commit
a hash, we simply take a recursive snapshot of the currently active GUID. When we want to switch to
a previous state, we create a new GUID and clone each of the volumes into that space, updating the
active pointer to the new GUID. Because we've stopped the container in between these operations, we
can update its mountpoint as needed. Note that from a hygeine perspective, it would be better to 

Listing commits is therefor just listing all the snapshots for each of the GUIDs and assembling them
together into a single list. The commit message is stored as a ZFS user property on the snapshot
(`com.delphix.titan:message`).

## Build

There are two separate projects, a server project and a client project. The former is the bulk of
the implementation, the latter is a wrapper around the APIs to make it easy to work with the
server.

```
./gradlew check assemble
```

This will build the server and client, run style checks, as well as unit tests and integration tests. It will
then package the server into the titan docker image. There is a third test target,
`endtoendTest`, that is not run automatically as part of `check` given how much longer it
can take. This should be run separately to perform the full barrage of tests, but will require
running the container, potentially connecting to external resources, etc.

To publish the image to dockerhub and the client to artifactory, run:

```
./gradlew publish
```

This should really only be done by CI/CD automation, and will require you to `docker login` with
appropriate privileges prior to pushing to the `delphix/titan` image.

## ZFS Packaging

One of the challenges we face is that it is unlikely that ZFS will be installed within the docker
VM of a developer laptop, which means that we need to take ownership of installing it for them.
But being a kernel module, we need to build it against the currently running kernel. We provide
pre-built kernel binaries for common MacOS and Windows docker VM kernels, but can also build
the modules at install time if we don't recognize the kernel. We'll also use an installed ZFS
version if it's compatible with our userland utilities, resulting in the following options:

 * Use the running ZFS version if it's installed and an acceptable version. Fail if it's an
   incompatible version.
 * If we have pre-built kernel binaries for the given environment (from `uname -r`), then 
   install those.
 * Otherwise, dynamically build new kernel binaries and install those.
 
We use the `delphix/zfs-builder` docker image to do the builds themselves. This tool takes the
kernel version, zfs version, and kernel `config.gz` file to build for any kernel. To manage our
pre-built userland binaries and kernel packages, we track configurations in the following places
in the source trees:

  * `zfs/config/$(uname -r)/config.gz` - The `config.gz` file for the given kernel, as extracted
    from `/proc/config.gz` on the system. Running `./gradlew getZfsConfig` will get the
    configuration from the currently running docker VM and place it in the appropriate place.
  * `zfs/kernel/$(uname -r).tar.gz` - The kernel modules for the given kernel. These can be
    created by running `./gradlew buildZfsKernel [-Puname=...]`. Given a specific uname, it
    will build only that kernel. Otherwise, it will build the default kernel. There is not
    currently a task that will build all known ZFS configurations - it has to be done one by one.
  * `zfs/userland/*` - This contains the extracted userland binaries for ZFS, ready to be copied
    into the docker container. Since they should (as of 0.8.0) maintain compatibility with a wide
    range of past kernel modules, we don't need to rebuild them for every distro, but can simply
    use the latet ones. The `./gradlew buildZfsUserland` task will rebuild and package these
    files.
    
The ZFS version we use is stored in `gradle/zfs.gradle.kts`. In the event we want to bump the
ZFS version, you will need to rebuild the userland binaries and all kernel distros. In the event
that storing these binaries in-tree becomes too expensive, we can move them to a shared package
repository and pull just the one we need at install time. But for now this is sufficient.

## OpenAPI and Generated API files

The original client and server skeletons were generated via the openapi code generator. However,
due to limitations with how that generator deals with things like polymorphism, errors, and 
non-standard member names, we instead hand-craft our clients on top of this base.

It can, however, still be useful to maintain the programmatic definition through openapi and
see how changes to the openapi definition would affect the generated code. For this reason, we
keep the openapi definition in `server/src/main/resources/openapi.yaml`, and automatically build
generated code at `src/generated` for both the client and server. This way, you can edit the
openapi file, see what would have changed, and ensure that those changes are reflected in the
hand-crafted versions of the files.
